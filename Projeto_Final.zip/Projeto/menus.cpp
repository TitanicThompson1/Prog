#include "menus.h"

int menuAgencia()
{

	int dec;																	//Menu Agencia: aqui o utilizador poder� escolher
																				//se quer ir para o Menu dos Clientes ou dos Pacotes ou comprar Pacote
	system("cls");

	
	cout << "Selecione o menu que quer aceder:" 
		<< endl
		<< endl << "0- Informacoes gerais"
		<< endl << "1- Clientes"
		<< endl << "2- Pacotes"
		<< endl << "3- Comprar pacote"
		<< endl << "4- Estatisticas"
		<< endl
		<< endl << "[-1] Sair" << endl;

	cin >> dec;

	//Verifica que dec est� dentro do espetro pretendido
	while (cin.fail() || dec < -1 || dec > 4 ) 
	{											
		cin.clear();
		cin.ignore(100, '\n');
		cerr << "Erro. Numero invalido. Por favor introduza um numero valido:  "; cin >> dec;
	}

	switch (dec)
	{
	case 0:
		return 6;
	case 1:

		return 1;
	case 2:

		return 3;
	case 3:

		return 5;
	case 4:

		return 7;

	case -1:
		return -1;

	default:
		
		break;
	}

}

int menuClientes(Agencia& agency)
{
	vector<Cliente>& clientes = agency.getVectorClient();

	int dec, nif, cancelar, pos_cliente;
	string dec_str;

	system("cls");
	cout << "Selecione a opcao que deseja efectuar:" << endl											
		<< "1- Ver clientes" << endl
		<< "2- Adicionar cliente" << endl
		<< "3- Eliminar cliente" << endl
		<< "4- Alterar cliente" << endl
		<< endl
		<< "[0] Voltar" << endl
		<< "[-1] Sair" << endl;


	cin >> dec;

	//Verifica que dec est� dentro do espetro pretendido
	while (dec < -1 || dec > 4 || cin.fail()) {																			
		cin.clear();
		cin.ignore(100, '\n');
		cerr << "Erro. Numero invalido. Por favor introduza um numero valido:  "; cin >> dec;
	}

	switch (dec)
	{
	case 0:

		return 0;
		break;
	case -1:

		return -1;
		break;
	case 1:

		return 2;


	case 2:
		
		system("cls");
		
		//cancelar = -1 se o utilizador cancelou; 0 caso contrario;
		cancelar = adicionaCliente(clientes);		
		

		system("cls");
		
		if (cancelar == -1)
		{
			return 1;
		}
		
		cout << "Cliente adicionado! :D" << endl;

		sort(clientes.begin(), clientes.end(), sort_clients);


		//atualiza as flags dos clients
		agency.UpdateClientsFlag();

		dec = opcao_a_realizar();

		if (dec == 0) {

			return 1;
		}
		else {

			return -1;
		}
		break;



	case 3:
		system("cls");

		if (clientes.size() == 0) {

			cout << "Nao existem clientes para eliminar!" << endl;
		}
		else {

			cout << "(Introduza 0 em qualquer momento para cancelar)" << endl << endl;

			lista_clientes_em_vector(clientes);
			cout << endl;
			cout << "Indroduza o nif do cliente" << endl; cin >> nif;
			
			//verifica se o NIF � valido
			while (cin.fail() || verifica_NIF(nif) != 9 || procuraPosCliente(clientes, nif) == -1 || nif == 0) {

				if (nif == 0 && !cin.fail())
				{
					return 1;
				}
				cin.clear();
				cin.ignore(1000, '\n');		
				
				if (procuraPosCliente(clientes, nif) == -1) 
				{																
					cerr << "NIF nao existe. Por favor introduza um NIF:  "; cin >> nif;							
				}																									
				else {																								
																													
					cerr << "NIF invalido. Por favor introduza um NIF:  "; cin >> nif;								
				}																									
			}																										
			
			system("cls");

			pos_cliente = procuraPosCliente(clientes, nif);

			dec_str = confirmarCliente(clientes.at(pos_cliente), "Deseja eliminar este cliente? Introduza S(Sim) ou N(Nao)");

			//verifica se o utilizador deseja cancelar
			if (dec_str == "N")
			{
				return 1;
			}

			eliminaCliente(clientes, nif);


			system("cls");

			cout << "Cliente eliminado! :D" << endl;

			//atualiza a flag dos clients
			agency.UpdateClientsFlag();

		}
		dec = opcao_a_realizar();

		if (dec == 0) {

			return 1;
		}
		else {

			return -1;
		}
		break;
	case 4:

		system("cls");
		if (clientes.size() == 0) {

			cout << "Nao existem clientes para alterar!" << endl;
		}
		else {
			
			cout << "(Introduza 0 em qualquer momento para cancelar)" << endl << endl;

			lista_clientes_em_vector(clientes);

			cout << endl;

			cancelar = alterarCliente(clientes);

			system("cls");

			//verifica se o utilizador deseja cancelar
			if (cancelar == -1)
			{
				return 1;
			}

			cout << "Cliente alterado! :D" << endl;

			//atualiza a flag dos clients
			agency.UpdateClientsFlag();
		}
		dec = opcao_a_realizar();

		if (dec == 0) {

			return 1;
		}
		else {

			exit(0);
		}
		break;

	default:

		exit(1);
		break;
	}



}

int menuClientesVer(Agencia& agency)
{
	vector<Cliente>& clientes = agency.getVectorClient();

	int dec;
	int nif;
	int pos_cliente;				//posicao do cliente no vetor
	system("cls");

	cout << "Selecione a opcao que deseja efectuar:" << endl
		<< "1- Ver informacao de todos os clientes " << endl
		<< "2- Ver informacao de um cliente" << endl
		<< endl
		<< "[0] Voltar" << endl
		<< "[-1] Sair" << endl;

	cin >> dec;

	//Verifica que dec est� dentro do espetro pretendido
	while (dec < -1 || dec > 3 || cin.fail()) {																			
		cin.clear();
		cin.ignore(100, '\n');
		cerr << "Erro. Numero invalido. Por favor introduza um numero valido:  "; cin >> dec;
	}

	switch (dec)
	{
	case 1:														

		system("cls");

		le_clientes_formatado(clientes);

		dec = opcao_a_realizar();
		if (dec == 0) {

			return 2;
		}
		else {

			return -1;
		}
		break;

	case 2:													

		system("cls");
		
		cout << "(Digite 0 para cancelar e voltar ao menu anterior)" << endl << endl;

		lista_clientes_em_vector(clientes);
		cout << endl;

		cout << "Indroduza o nif do cliente" << endl; cin >> nif;

		pos_cliente = procuraPosCliente(clientes, nif);

		//verifica se o NIF � valido
		while (cin.fail() || verifica_NIF(nif) != 9 || pos_cliente == -1) {								
			
			if (nif == 0 && !cin.fail())
			{
				return 2;
			}

			cin.clear();																						
			cin.ignore(1000, '\n');																													 
			cerr << "NIF nao valido. Por favor introduza um NIF:  "; cin >> nif;
			pos_cliente = procuraPosCliente(clientes, nif);
		}																										
		system("cls");

		cout << clientes.at(pos_cliente);

		cout << endl;

		dec = opcao_a_realizar();
		if (dec == 0) {

			return 2;
		}
		else {

			return -1;
		}
		break;
	
	case -1:

		return -1;
	case 0:

		return 1;

		break;
	default:
		break;
	}
}

int menuPacotes(Agencia& agency)
{
	vector<Packet> &packs = agency.getVectorPack();
	int dec, cancela;
	Packet temp;

	system("cls");
	cout << "Selecione a opcao que deseja efectuar:" << endl
		<< "1- Ver pacotes" << endl
		<< "2- Criar pacote" << endl
		<< "3- Eliminar pacote" << endl
		<< "4- Alterar pacote" << endl
		<< endl
		<< "[0] Voltar" << endl
		<< "[-1] Sair" << endl;

	cin >> dec;

	//Verifica que dec est� dentro do espetro pretendido
	while (dec < -1 || dec > 4 || cin.fail()) {
		cin.clear();
		cin.ignore(100, '\n');
		cerr << "Erro. Numero invalido. Por favor introduza um numero valido:  "; cin >> dec;
	}
	switch (dec)
	{
	case -1:										
		return -1;
	case 0:
		return 0;
		break;
	case 1:
		return 4;
		break;
	case 2:

		system("cls");										

		cancela = criarPacote(temp,packs.at(packs.size()-1).getId());

		//verifica se o utilizador pretende cancelar
		if (cancela == 1)
		{
			return 3;
		}

		packs.push_back(temp);

		system("cls");
		
		cout << "Pacote criado! :D" << endl;

		//atualiza a flag dos pacotes
		agency.UpdatePacotesFlag();

		dec = opcao_a_realizar();
		if (dec == 0) {

			return 3;
		}
		else {

			return -1;
		}

	case 3:

		system("cls");												
		
		if (packs.size()==0) {

			cout << "N�o existem pacotes para eliminar!" << endl;
		}
		else {
			cout << "(Introduza 0 em qualquer momento para cancelar)" << endl << endl;
			
			lista_pacotes_em_vector(packs);
			cout << endl;
			cancela = eliminaPacote(packs);
			
			//verifica se o utilizador pretende cancelar
			if (cancela == 1)
			{
				return 3;
			}

			system("cls");
			cout << "Pacote eliminado! :D" << endl;

			//atualiza a flag dos pacotes
			agency.UpdatePacotesFlag();
		}
		dec = opcao_a_realizar();
		if (dec == 0) {

			return 3;
		}
		else {

			return -1;
		}
	case 4:

		system("cls");											
		if (packs.size() == 0) {

			cout << "N�o existem pacotes para alterar!" << endl;
		}
		else {

			cout << "(Introduza 0 em qualquer momento para cancelar)" << endl << endl;

			lista_pacotes_em_vector(packs);
			cout << endl;

			cancela=alterarPacote(packs);

			//verifica se o utilizador pretende cancelar
			if (cancela == 1)
			{
				return 3;
			}

			system("cls");

			cout << "Pacote alterado! :D" << endl;

			//atualiza a flag dos pacotes
			agency.UpdatePacotesFlag();
		}
		dec = opcao_a_realizar();
		if (dec == 0) {

			return 3;
		}
		else {

			return -1;
		}

	default:
		break;
	}
}
 
int menuPacoteVer(Agencia& agency)
{
	vector<Packet> &packs = agency.getVectorPack();
	vector<Cliente>& clientes = agency.getVectorClient();
	Cliente temp;

	Date begin, end, empty;
	string destino;
	int dec, id, max_id;
	int pos_pacote, nif;
	system("cls");

	cout << "Selecione a opcao que deseja efectuar:" << endl
		<< "1- Ver informacao de todos os pacotes " << endl
		<< "2- Ver informacao de um pacote" << endl
		<< "3- Ver pacotes vendidos" << endl
		<< "4- Ver pacoes vendidos de um cliente" << endl
		<< "5- Pesquisar por destino especifico" << endl
		<< "6- Pesquisar entre duas datas" << endl
		<< "7- Pesquisar por destino especifico e entre duas datas" << endl
		<< endl
		<< "[0] Voltar" << endl
		<< "[-1] Sair" << endl;
	cin >> dec;

	//Verifica que dec est� dentro do espetro pretendido
	while (dec < -1 || dec > 7 || cin.fail()) {																			
		cin.clear();
		cin.ignore(100, '\n');
		cerr << "Erro. Numero invalido. Por favor introduza um numero valido:  "; cin >> dec;
	}

	switch (dec)
	{
	case 1:													

		system("cls");

		le_pacotes_formatado(packs);

		dec = opcao_a_realizar();
		if (dec == 0) {

			return 4;
		}
		else {

			return -1;
		}
		break;
	case 2:												

		system("cls");

		if (packs.size() == 0) {

			cout << "N�o existem pacotes para eliminar!" << endl;
		}
		else {
			
			cout << "(Introduza 0 em qualquer momento para cancelar)" << endl << endl;

			lista_pacotes_em_vector(packs);

			cout << endl << "Introduza o numero do pacote que pretende aceder:  "; cin >> id;

			max_id = abs(packs.at(packs.size() - 1).getId());

			//verifica se o id � v�lido
			while (id > max_id || id==0 || cin.fail()) {
				
				//verifica se o utilizador pretende cancelar
				if (id == 0 && !cin.fail())
				{
					return 4;
				}
				cin.clear();
				cin.ignore(100,'\n');
				cerr << "Erro. Pacote nao existente. Introduza pacote valido:  "; cin >> id;
				
			}

			system("cls");

			pos_pacote = procuraPosPacote(packs, 0, id);

			le_pacote_formatado(packs, pos_pacote);

		}
		dec = opcao_a_realizar();
		if (dec == 0) {

			return 4;
		}
		else {

			return -1;
		}
		break;

	case 3:

		system("cls");

		procuraPacotesVendidos(packs);

		dec = opcao_a_realizar();
		if (dec == 0) {

			return 4;
		}
		else {

			return -1;
		}
		break;

	case 4:

		system("cls");

		cout << "(Introduza 0 em qualquer momento para cancelar)" << endl << endl;

		lista_clientes_em_vector(clientes);
		cout << endl;
		cout << "Indroduza o nif do cliente" << endl; cin >> nif;

		//verifica se o NIF � valido
		while (cin.fail() || verifica_NIF(nif) != 9 || procuraPosCliente(clientes, nif) == -1 || nif == 0) {

			if (nif == 0 && !cin.fail())
			{
				return 4;
			}
			cin.clear();
			cin.ignore(1000, '\n');

			if (procuraPosCliente(clientes, nif) == -1)
			{
				cerr << "NIF nao existe. Por favor introduza um NIF:  "; cin >> nif;
			}
			else {

				cerr << "NIF invalido. Por favor introduza um NIF:  "; cin >> nif;
			}
		}

		temp = clientes.at(procuraPosCliente(clientes, nif));

		system("cls");

		lista_pacotes_de_cliente(temp, packs);

		dec = opcao_a_realizar();
		if (dec == 0) {

			return 4;
		}
		else {

			return -1;
		}
		break;


	case 5:

		system("cls");

		cout << "(Introduza 0 em qualquer momento para cancelar)" << endl << endl;

		cout << "Introduza o destino:  "; 

		cin.ignore();
		getline(cin, destino);

		//verifica se o utilizador pretende cancelar
		if (destino == "0")
		{
			return 4;
		}

		system("cls");
		procuraPorDestino(packs, destino);

		dec = opcao_a_realizar();
		if (dec == 0) {

			return 4;
		}
		else {

			return -1;
		}
		break;
	case 6:

		system("cls");

		cout << "(Introduza 0 em qualquer momento para cancelar)" << endl << endl;
		cout << "Introduza a 1� data" << endl;

		begin.insertDate();

		//verifica se quer cancelar
		if (begin == empty)
		{
			return 4;
		}

		cout << "Introduza a 2� data" << endl;
		end.insertDate();

		
		while (end < begin)
		{

			//verifica se quer cancelar
			if (end == empty)
			{
				return 4;
			}
			cerr << "Data de fim invalida: Introduza uma data valida" << endl;
			end.insertDate();
		}
		system("cls");

		procuraPorDatas(packs, begin, end);

		dec = opcao_a_realizar();
		if (dec == 0) {

			return 4;
		}
		else {

			return -1;
		}
		break;
	case 7:

		system("cls");

		cout << "(Introduza 0 em qualquer momento para cancelar)" << endl << endl;

		cout << "Introduza o destino:  ";

		cin.ignore();
		getline(cin, destino);

		if (destino == "0")
		{
			return 4;
		}

		cout << "Introduza a 1� data" << endl;

		begin.insertDate();

		//verifica se quer cancelar
		if (begin == empty)
		{
			return 4;
		}

		cout << "Introduza a 2� data" << endl;
		end.insertDate();


		while (end < begin)
		{

			//verifica se quer cancelar
			if (end == empty)
			{
				return 4;
			}
			cerr << "Data de fim invalida: Introduza uma data valida" << endl;
			end.insertDate();
		}

		system("cls");

		procuraPorDestinoEDatas(packs, destino, begin, end);

		dec = opcao_a_realizar();
		if (dec == 0) {

			return 4;
		}
		else {

			return -1;
		}

		break;

	case -1:
		return -1;
	case 0:
		return 3;
		break;
	default:
		break;
	}
}

int menuInfo(Agencia& agency)
{

	int dec;

	system("cls");
	cout << "Selecione a opcao que deseja efectuar:" << endl
		<< "1- Ver agencia" << endl
		<< "2- Numero e total de pacotes vendidos" << endl
		<< endl
		<< "[0] Voltar" << endl
		<< "[-1] Sair" << endl;
	cin >> dec;

	//Verifica que dec est� dentro do espetro pretendido
	while (dec < -1 || dec > 2 || cin.fail()) {
		cin.clear();
		cin.ignore(100, '\n');
		cerr << "Erro. Numero invalido. Por favor introduza um numero valido:  "; cin >> dec;
	}

	switch (dec)
	{
	case 1:
		system("cls");

		cout << agency << endl;

		dec = opcao_a_realizar();
		if (dec == 0) {

			return  6;
		}
		else {

			return -1;
		}
		break;
	case 2:
		system("cls");
		
		total(agency.getVectorPack(), agency.getVectorClient());

		dec = opcao_a_realizar();

		if (dec == 0) {

			return 6;
		}
		else {

			return -1;
		}
		break;
	case 0:
		return 0;
	case -1:
		return -1;

	default:
		break;
	}
	
}

int menuComprar(Agencia& agency)
{
	vector<Packet> &packs = agency.getVectorPack();
	vector<Cliente> &clientes = agency.getVectorClient();

	int client_nif, did_it, dec;
	int pos_pacote;
	int pos_cliente;
	unsigned int pacote;
	string continua;

	system("cls");
	if (packs.size() == 0 || clientes.size() == 0) {

		cout << "O ficheiro dos clientes e/ou dos pacotes esta vazio!" << endl;
	}
	else {
		
		cout << "(Introduza 0 em qualquer momento para cancelar)" << endl << endl;

		lista_clientes_em_vector(clientes);


		cout << endl << "Qual o nif do cliente que quer comprar um pacote?  "; cin >> client_nif;
		
		
		while (procuraPosCliente(clientes,client_nif) == -1 || cin.fail())
		{
			//verifica se o utilizador pretende cancelar
			if (client_nif == 0 && !cin.fail())
			{
				return 0;
			}
			cin.clear();
			cin.ignore(1000, '\n');
			cerr << "Erro. NIF nao encontrado. Por favor introduza um NIF valido:  "; cin >> client_nif;

		}
		
		pos_cliente = procuraPosCliente(clientes, client_nif);

		system("cls");

		cout << "(Introduza 0 em qualquer momento para cancelar)" << endl << endl;

		lista_pacotes_em_vector(packs);

		cout << endl << "Qual o pacote que quer comprar? (os pacotes com um numero negativo estao esgotados, nao devem ser selecionados)  "; cin >> pacote;
		
		

		pos_pacote = procuraPosPacote(packs, 0, pacote);
		
		//verifica se id � valido e se existe
		while ( cin.fail() || pacote==0 ||pacote > abs(packs.at(packs.size()-1).getId())  || pacote != packs.at(pos_pacote).getId() )			
		{						
			if (pacote == 0 && !cin.fail())
			{
				return 0;
			}
			cin.clear();
			cin.ignore(1000, '\n');
			
			cerr << "Erro. Pacote invalido. Introduza um pacote valido:  "; cin >> pacote;
			pos_pacote = procuraPosPacote(packs, 0, pacote);

		}
		
		if (packs.at(pos_pacote).getSoldSeats() + clientes.at(pos_cliente).getAgre() > packs.at(pos_pacote).getMaxPersons())
		{
			system("cls");
			cerr << "Erro: Nao existem vagas suficientes. Introduza 0 para voltar para o menu anterior  "; cin >> continua;
			return 0;
		}
		pos_pacote = procuraPosPacote(packs, 0, pacote);

		did_it = compra_pacote(packs.at(pos_pacote), clientes.at(pos_cliente));

		

		system("cls");

		if (did_it == 0) 
		{
			cout << "Pacote comprado! :D" << endl;

			//atualiza a flag dos clients
			agency.UpdateClientsFlag();

			//atualiza a flag dos pacotes
			agency.UpdatePacotesFlag();
		}
		else 
		{
			cerr << "O cliente ja comprou este pacote! :(" << endl;
		}
	}
	dec = opcao_a_realizar();
	if (dec == 0) {

		return 0;
	}
	else {

		return -1;
	}
}

int menuEstatistica(Agencia& agency)
{
	vector<Packet> &packs = agency.getVectorPack();
	vector<Cliente> &clientes = agency.getVectorClient();
	int dec, cancelar;

	system("cls");
	cout << "Selecione a opcao que deseja efectuar:" << endl											
		<< "1- N locais mais visitidas" << endl
		<< "2- Recomenda��es para todos os clientes" << endl
		<< endl
		<< "[0] Voltar" << endl
		<< "[-1] Sair" << endl;


	cin >> dec;

	//Verifica que dec est� dentro do espetro pretendido
	while (dec < -1 || dec > 2 || cin.fail()) {		

		cin.clear();
		cin.ignore(100, '\n');
		cerr << "Erro. Numero invalido. Por favor introduza um numero valido:  "; cin >> dec;
	}

	switch (dec)
	{
	case 1:
		system("cls");

		cancelar = mostVisitedPlaces(packs);

		if (cancelar == -1)
		{
			return 7;
		}

		dec = opcao_a_realizar();
		if (dec == 0) {

			return 7;
		}
		else {

			return -1;
		}
		break;
	case 2:
		system("cls");

		cancelar = clientsRecomendation(packs, clientes);

		if (cancelar == -1)
		{
			return 7;
		}

		dec = opcao_a_realizar();

		if (dec == 0) {

			return 7;
		}
		else {

			return -1;
		}
		break;

	case 0:
		return 0;
	case -1:
		return -1;

	default:
		break;
	}
}