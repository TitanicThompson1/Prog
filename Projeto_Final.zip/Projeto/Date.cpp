#include"Date.h"


Date::Date() {
	year = 0;
	month = 0;
	day = 0;

}

Date::Date(string date) {

	istringstream str_date(date);

	vector<string> s;
	string aux_str = "";
	//obter elementos da data
	while (getline(str_date, aux_str, '/')) {

		s.push_back(aux_str);

	}

	year = stoi(s[0]);
	month = stoi(s[1]);
	day = stoi(s[2]);


}

Date::Date(unsigned short day, unsigned short month, unsigned year) {

	this->year = year;
	this->month = month;
	this->day = day;
}

/*********************************
 * GET Methods
 ********************************/
unsigned short Date::getDay() const {

	return day;
	// REQUIRES IMPLEMENTATION

}

unsigned short Date::getMonth() const {

	
	return month;
}

unsigned Date::getYear() const {
	
	return year;
}

/*********************************
 * SET Methods
 ********************************/

void Date::setDay(unsigned short day) {

	this->day = day;
}

void Date::setMonth(unsigned short month) {

	this->month = month;
}

void Date::setYear(unsigned year) {

	this->year = year;
}


/*********************************
 * Show Date
 ********************************/

 // disply a Date in a nice format
ostream& operator<<(ostream& out, const Date & date) {

	//vamos definir como o operador << se comporta com a classe DATE!!

	return  out << right << setfill('0') << setw(4) << date.getYear() << "/" << setfill('0') << setw(2) << date.getMonth() << "/" << setfill('0') << setw(2) << date.getDay() << setfill(' ');
	
}


void Date::insertDate() {
	//vari�vel para validar data a ser inserida
	bool valid_date = false;

	Date date, empty;
	//objecto da classe date que ser� retornado

	unsigned short year, month, day;

	//ciclo continua enquanto data for inv�lida
	while (!valid_date) {
		Date aux_date;
		//Obter informa��o para a data do que � inserido

		
		cout << "Ano: ";
		cin >> year;


		//verifica se o utilizador deseja cancelar
		if (year == 0 && !cin.fail())
		{
			this->year = 0;
			this->month = 0;
			this->day = 0;
			return;
		}

		if (cin.fail())
		{
			cin.clear();
			cin.ignore(1000, '\n');
		}

		cout << "M�s: ";
		cin >> month;


		//verifica se o utilizador deseja cancelar
		if (month == 0 && !cin.fail())
		{
			this->year = 0;
			this->month = 0;
			this->day = 0;
			return;
		}

		if (cin.fail())
		{
			cin.clear();
			cin.ignore(1000, '\n');
		}

		cout << "Dia: ";
		cin >> day;

		//verifica se o utilizador deseja cancelar
		if (day == 0 && !cin.fail())
		{
			this->year = 0;
			this->month = 0;
			this->day = 0;
			return;
		}
		//Controlar se data inserida � v�lida



		if (!cin) {
			cerr << "Data inserida invalida, tente novamente!" << endl;
			cin.clear();
			cin.ignore(1000, '\n');


		}

		else {


			//Controla se data inserida � v�lida tendo em conta as regras para as mesmas
			aux_date = Date(day, month, year);
			if (aux_date.validDate()) {
				valid_date = true;
				this->year = year;
				this->month = month;
				this->day = day;
			}
			else {
				cerr << "Date inserida invalida, ano, m�s ou dia fora da gama permitida, tente novamente!" << endl;

			}
		}
		//Controla se data inserida � v�lida tendo em conta as regras para as mesmas
	}


	
}


bool Date::validDate() {

	//ano bissexto 
	if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0 and year % 100 == 0)) {
		if ((month == 1 || month == 3 || month == 5 || month == 7 || month == 9 || month == 11) and (day >= 1 and day <= 31)) {

			return true;
		}
		else if ((month == 4 || month == 6 || month == 8 || month == 10 || month == 12) and (day >= 1 and day <= 30)) {
			return true;
		}
		else {
			if (month == 2 and (day >= 1 and day <= 29)) {
				return true;
			}

		}


	}
	//resto dos anos
	else {

		//calend�rio gregoriano come�a o ano com 1, tendo passado de 1 a.C. para 1 a.D.
		//
		if (year >= 1) {
			if ((month == 1 || month == 3 || month == 5 || month == 7 || month == 9 || month == 11) and (day >= 1 and day <= 31)) {

				return true;
			}
			else if ((month == 4 || month == 6 || month == 8 || month == 10 || month == 12) and (day >= 1 and day <= 30)) {
				return true;
			}
			else {
				if (month == 2 and (day >= 1 and day <= 28)) {
					return true;
				}

			}




		}

	}

	return false;

}


bool operator<(const Date& begin, const Date& end)
{

	//Situa��es poss�veis de compara��o da data 1 com data 2
	if (begin.year < end.year) {

		return true;
	}
	else if (begin.year == end.year && begin.month < end.month) {
		return true;
	}
	else if (begin.year == end.year && begin.month == end.month && begin.day < end.day) {
		return true;

	}


	else {
		return false;
	}
}

bool operator==(const Date& d1, const Date& d2)
{
	if (d1.year == d2.year && d1.month == d2.month && d1.day == d2.day)				//compara o ano, o mes e o dia das duas datas
	{
		return true;
	}
	return false;
}

bool operator>(const Date& begin, const Date& end)
{
	if (begin.year > end.year) {

		return true;
	}
	else if (begin.year == end.year && begin.month > end.month) {
		return true;
	}
	else if (begin.year == end.year && begin.month == end.month && begin.day > end.day) {
		return true;

	}


	else {
		return false;
	}
}

bool operator<=(const Date& begin, const Date& end)
{


	//Situa��es poss�veis de compara��o da data 1 com data 2
	if (begin.year < end.year) {

		return true;
	}
	else if (begin.year == end.year && begin.month < end.month) {
		return true;
	}
	else if (begin.year == end.year && begin.month == end.month && begin.day <= end.day) {
		return true;

	}


	else {
		return false;
	}
}

bool operator>=(const Date& begin, const Date& end)
{
	if (begin.year > end.year) {

		return true;
	}
	else if (begin.year == end.year && begin.month > end.month) {
		return true;
	}
	else if (begin.year == end.year && begin.month == end.month && begin.day >= end.day) {
		return true;

	}


	else {
		return false;
	}
}