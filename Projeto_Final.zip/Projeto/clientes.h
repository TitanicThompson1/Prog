#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <algorithm>

#include "Address.h"

using namespace std;


class Cliente {
public:

	//Constructor
	Cliente();					

	void addCliente(string _nome, int _nif, unsigned _agregado, Address _morada);			//fun��o adiciona clientes
	void fillCliente(string _nome, int _nif, unsigned _agregado, Address _morada, string _pacotesComprados, int _total);


	//Metodos GET
	int getNIF();																		
	Address getMorada();																	
	unsigned getAgre();																	
	string getNome();																	
	string getPac();																	
	int getTotal();																		
	vector<int> getVectorPack();

	//Metodos SET
	void setNome(string _nome);																
	void setNIF(int _nif);																	
	void setAgre(unsigned _agregado);														
	void setMorada(Address _morada);														
	void setPac(string _pacotesComprados);
	void setTotal(int _total);

	//formata o cout
	friend ostream& operator<<(ostream& out, const Cliente &client);

	//instrui em como efectuar a operacao de <
	friend bool &operator < (Cliente &c1, Cliente &c2);

														

private:

	string nome;
	int nif;
	unsigned agregado;
	Address morada;
	string pacotesComprados;
	int total;
};