#include "Address.h"

Address::Address(){

	street = "DESCONHECIDO";
	doorNumber = -1;
	floor = "DESCONHECIDO";
	postalCode = "DESCONHECIDO";
	location = "DESCONHECIDO";

}

Address::Address(string street, unsigned short doorNumber, string floor, string postalCode, string location){

	this->street = street;
	this->doorNumber = doorNumber;
	this->floor = floor;
	this->postalCode = postalCode;
	this->location = location;

}


  // metodos GET

string Address::getStreet() const{

	return street;
}

unsigned short Address::getDoorNumber() const{

	return doorNumber;
}

string Address::getFloor() const{
  
	return floor;
}

string Address::getPostalCode() const{

	return postalCode;
}

string Address::getLocation() const{

	return location;
}

string Address::getAddressFormated() const
{
	return street + " / " + to_string(doorNumber) + " / " + floor + " / " + postalCode + " / " + location;

}

  // metodos SET

void Address::setAddress(string street, unsigned short doorNumber, string floor, string postalCode, string location)
{
	this->street = street;
	this->doorNumber = doorNumber;
	this->floor = floor;
	this->postalCode = postalCode;
	this->location = location;
}

void Address::setStreet(string street){

	this->street = street;
}

void Address::setDoorNumber(unsigned short doorNumber){

	this->doorNumber = doorNumber;
}

void Address::setFloor(string floor){

	this->floor = floor;

}

void Address::setPostalCode(string postalCode){

	this->postalCode = postalCode;
}

void Address::setLocation(string  location){

	this->location = location;
}


void Address::getAddressFromString(string morada)
{
	istringstream stream_morada(morada);				
	string temp;
	vector<string> temp2;


	while (getline(stream_morada, temp, '/'))								//como a morada est� formatada com /, o getline ir� retirar da stream at� ao proximo /.
	{
		temp2.push_back(temp);
	}

	street = temp2.at(0);
	street = street.substr(0, street.size() - 1);							//esta instrucao retira os espacos em branco no fim da string

	doorNumber = stoi(temp2.at(1));
	
	floor = temp2.at(2);
	floor = floor.substr(1, floor.size() - 2);								//esta instrucao retira os espacos em branco no fim e no inicio da string 

	postalCode = temp2.at(3);
	postalCode = postalCode.substr(1, postalCode.size() - 2);				//esta instrucao retira os espacos em branco no fim e no inicio da string 

	location = temp2.at(4);	
	location = location.substr(1, location.size());							//esta instrucao retira os espacos em branco no inicio da string

}


/*********************************
 * Mostrar Address
 ********************************/

// discplyes an address in a nice format
ostream& operator<<(ostream& out, const Address & address){

	return out << "Rua:  " << address.street
		<< endl << "N�:  " << address.doorNumber
		<< endl << "Andar:  " << address.floor
		<< endl << "Codigo-Postal:  " << address.postalCode
		<< endl << "Localidade:  " << address.location;

}
