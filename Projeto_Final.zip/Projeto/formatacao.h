#pragma once
#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>


#include "clientes.h"
#include "listagem.h"
#include "Packet.h"

using namespace std;

/*
@L� clientes de um vetor de clientes num modo formatado (na consola);
clients: vetor de clientes;
RETURN: void.
*/
void le_clientes_formatado(vector<Cliente> clients);

/*
@L� pacotes de um vector de pacotes num modo formatado (na consola);
packs: vector de pacotes;
RETURN: void.
*/
void le_pacotes_formatado(vector<Packet> packs);

void le_pacote_formatado(vector<Packet> packs, int pos_pacote);
