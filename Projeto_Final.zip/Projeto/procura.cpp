#include <iostream>

#include "formatacao.h"
#include "clientes.h"
#include "Packet.h"


int procuraPosCliente(vector<Cliente> clients, int _nif)
{
   //efectua se uma binary search

   int min = 0;
   int max = clients.size() - 1;
   int guess;
   int pos_guess;
   while (min <= max)
   {
      pos_guess = (int)(min + max) / 2;
      guess = clients.at(pos_guess).getNIF();

      if (_nif == guess)
      {
         return pos_guess;
      }
      else if (guess < _nif) {
         min = pos_guess + 1;
      }
      else {
         max = pos_guess - 1;
      }

   }

   return -1;
}

int procuraPosPacote(vector<Packet> &packs, int minimum_left_position, int Id)
{
   //efectua se uma binary search

   int vector_length = packs.size() - 1;

   //controlar at� quando se procura o Id
   while (minimum_left_position <= vector_length) {
      int mid = minimum_left_position + (vector_length - minimum_left_position) / 2;

      //Id est� no posi��o mid
      if (abs(packs.at(mid).getId()) == abs(Id))
         return mid;
      //Se Id � maior, continuamos a procura no lado esquerdo do vector depois da posi��o mid
      else if (abs(packs.at(mid).getId()) < abs(Id)) {

         minimum_left_position = mid + 1;
      }
      else {
         // Id � menor, continuamos a procura no lado direito do vector depois da posi��o mid
         vector_length = mid - 1;

      }

   }
   //n�o encontrou Id no vector
   return -1;
}

template <typename T>
bool procuraValorVector(vector<T> vetor, T valor)
{
   for (int i = 0; i < vetor.size(); i++)
   {
      if (vetor.at(i) == valor)
      {
         return true;
      }
   }
   return false;
}

void procuraPorDestino(vector<Packet> packs, string destino)
{

   vector<Packet> temp;

   for (int i = 0; i < packs.size(); i++)
   {
      //verifica se o pacote tem o destino pretendido
      if (procuraValorVector(packs.at(i).getPlaces(), destino))
      {
         temp.push_back(packs.at(i));

      }

   }
   le_pacotes_formatado(temp);
}

void procuraPorDatas(vector<Packet> packs, Date begin, Date end)
{
   vector<Packet> temp;
   for (int i = 0; i < packs.size(); i++)
   {
      //verifica se o pacote est� entre as datas pretendidas
      if ((packs.at(i).getBeginDate() >= begin) && (packs.at(i).getEndDate() <= end))
      {
         temp.push_back(packs.at(i));
      }
   }
   le_pacotes_formatado(temp);

}

void procuraPorDestinoEDatas(vector<Packet> packs, string destino, Date begin, Date end)
{
   vector<Packet> temp;
   for (int i = 0; i < packs.size(); i++)
   {
      //verifica se o pacote est� entre as datas pretendidas e tem o destino pretendido
      if ((packs.at(i).getBeginDate() >= begin) && (packs.at(i).getEndDate() <= end) && procuraValorVector(packs.at(i).getPlaces(), destino))
      {
         temp.push_back(packs.at(i));
      }
   }

   le_pacotes_formatado(temp);

}

int procuraPosPacoteComprados(vector<int> packs, int id)
{

   //efectua se uma binary search

   int min = 0;
   int max = packs.size() - 1;
   int guess;
   int pos_guess;
   while (min <= max)
   {
      pos_guess = (int)(min + max) / 2;
      guess = packs.at(pos_guess);

      if (id == guess)
      {
         return pos_guess;
      }
      else if (guess < id) {
         min = pos_guess + 1;
      }
      else {
         max = pos_guess - 1;
      }

   }

   return -1;
}

void procuraPacotesVendidos(vector<Packet> packs)
{
   vector<int> pacotes;
   vector<Packet> result;


   for (int i = 0; i < packs.size(); i++)
   {
      if (packs.at(i).getSoldSeats() != 0)
      {
         result.push_back(packs.at(i));
      }
   }
   le_pacotes_formatado(result);

}