#include "gerar.h"

void gerar()
{
	srand(time(NULL));
	vector<string> nomes = vetorNomes();
	vector<string> locais = vetorLocais();
	vector<int> inteiros = vetorInteiros();
	vector<int> NIFs = vetorNIF();

	int pos_nome, pos_local, pos_inteiros, pos_NIF;

	ofstream outfile1("clients.txt");
	ofstream outfile2("packs.txt");

	//Clientes
	for (int i = 0; i < 100; i++)
	{
		pos_nome = rand() % (nomes.size() - 1);
		pos_inteiros = rand() % (inteiros.size() - 1);
		pos_NIF = rand() % (NIFs.size() - 1);

		outfile1 << nomes.at(pos_nome) << endl;
		outfile1 << NIFs.at(pos_NIF) << endl;
		outfile1 << inteiros.at(pos_inteiros) << endl;
		outfile1 << "Rua Tomas das Calcas / 20 / - / 950558 / 1" << endl;
		outfile1 << "-" << endl;
		outfile1 << 0 << endl;
		if (i != 99)
		{
			outfile1 << "::::::::::" << endl;
		}

	}
	outfile1.close();

	//Pacotes
	outfile2 << 100 << endl;
	for (int i = 1; i < 101; i++)
	{
		pos_local = rand() % (locais.size() - 1);
		pos_inteiros = rand() % (inteiros.size() - 1);
		pos_NIF = rand() % (NIFs.size() - 1);

		outfile2 << i << endl;
		outfile2 << locais.at(pos_local) << endl;
		outfile2 << "2019/01/01" << endl;
		outfile2 << "2019/02/01" << endl;

		outfile2 << inteiros.at(pos_inteiros) << endl;
		pos_inteiros = rand() % (inteiros.size() - 1);

		outfile2 << inteiros.at(pos_inteiros) << endl;
		pos_inteiros = rand() % (inteiros.size() - 1);

		outfile2 << 0 << endl;

		if (i != 100)
		{
			outfile2 << "::::::::::" << endl;
		}

	}
	outfile2.close();
}

vector<string> vetorNomes()
{
	string temp;
	ifstream infile("nomes.txt");
	vector<string> result;


	while(getline(infile,temp))
	{
		result.push_back(temp);
	}
	return result;
}

vector<string> vetorLocais()
{
	string temp;
	ifstream infile("locais.txt");
	vector<string> result;


	while (getline(infile, temp))
	{
		result.push_back(temp);
	}
	return result;
}

vector<int> vetorInteiros()
{
	vector<int> result;
	for (int i = 1; i < 1000; i++)
	{
		result.push_back(i);
	}
	return result;
}

vector<int> vetorNIF()
{
	vector<int> result;
	for (int i = 111111111; i < 111112111; i++)
	{
		result.push_back(i);
	}
	return result;
}
