#include <iostream>

#include "clientes.h"
#include "Packet.h"

using namespace std;

bool sort_clients(Cliente c1, Cliente c2)
{
	return c1.getNIF() < c2.getNIF();

}
bool sort_pacotes(Packet p1, Packet p2)
{
	return abs(p1.getId()) < abs(p2.getId());
}


bool sortPlacesVisited(pair<string, int> place1, pair<string, int> place2) {

	return (place1.second) > (place2.second);
}