#pragma once

#include <iostream>
#include <string>
#include <vector>


#include "defs.h"
#include "Date.h"

using namespace std;

class Packet{

private:
	int id; // packet unique identifier
	vector<string> places; // touristic sites to visit
	Date begin;  // begin date
	Date end;  // end date
	double pricePerPerson; // price per person
	unsigned maxPersons; // number of persons still available in the packet (updated whenever the packet is sold to a new client)
	unsigned soldSeats;	 // number of sold seats

public:

	//Constructor
	Packet();
	Packet(int id, vector<string> &places, Date begin, Date end, double pricePerPerson, unsigned maxPersons,unsigned soldSeats);

	// GET methods
	int getId() const;
	vector<string> getPlaces() const;
	Date getBeginDate() const;
	Date getEndDate() const;
	double getPricePerPerson() const;
	unsigned getMaxPersons() const;
	unsigned getSoldSeats() const;

	// SET methods
	void setId(unsigned id);  
	void setPlaces(vector<string> &places);
	void setBeginDate(Date begin);
	void setEndDate(Date end);
	void setPricePerPerson(double pricePerPerson);
	void setMaxPersons(unsigned maxPersons);
	void setSoldSeats(unsigned soldSeats) ;

// other methods
//criar m�todo que l� informa��o de pacote de forma exped�ta read().....

  /*@Obter s�tios a visitar de forma formatada
  @param packet � o pacote para obter os s�tios
  @return os s�tios de forma formatada*/

  string getPlacesFormated() const;

 /*
 @Obtemos vector com os s�tios a visitar de um pacote de uma string com s�tios pretendidos
   @param places string com os s�tios de um pacote
   @return um vector com os s�tios do pacote
   */

  vector<string> getPlacesFromString(string places);

  

  /*
  @Define como informa��o sobre pacotes ser� apresentada usando operador <<
     @param  out � um objecto output stream que permite escrever caracteres entre outras coisas
     @ param packet � o pacote do qual queremos obter informa��o usando o operador <<
     @ return a informa��o referente ao pacote da forma que pretendemos
	 */
  friend ostream& operator<<(ostream& out, const Packet &packet);

  
  
};
