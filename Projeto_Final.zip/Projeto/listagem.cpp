
#include "listagem.h"

/*
void lista_clientes_em_vector(vector<Cliente> clients)
{

	for (int i = 0; i < clients.size(); i++)
	{
		cout << clients.at(i).getNome() << " - " << clients.at(i).getNIF() << endl;
	}
}

void lista_pacotes_em_vector(vector<Packet> packs) {

														
	for (int i = 0; i < packs.size(); i++)
	{
		cout << packs.at(i).getId() << " - " << packs.at(i).getPlacesFormated() << endl;
	}
}
*/
void lista_pacotes_de_cliente(Cliente clients, vector<Packet> packs)
{
	int pos_pacote;
	vector<int> pacotes = clients.getVectorPack();
	vector<Packet> result;

	for (int i = 0; i < pacotes.size(); i++)
	{

		pos_pacote = procuraPosPacote(packs, 0, pacotes.at(i));
		result.push_back(packs.at(pos_pacote));

	}
	le_pacotes_formatado(result);
}

