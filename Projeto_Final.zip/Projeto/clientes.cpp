#include "clientes.h"


Cliente::Cliente()
{
	nome = "DESCONHECIDO";
	nif = 0;
	agregado = 0;
	Address mor;
	morada = mor;
	pacotesComprados = "DESCONHECIDO";
	total = -1;

}

void Cliente::addCliente(string _nome, int _nif, unsigned _agregado, Address _morada)
{
	nome = _nome;
	nif = _nif;
	agregado = _agregado;
	morada = _morada;
	pacotesComprados = "-";
	total = 0;
}

void Cliente::fillCliente(string _nome, int _nif, unsigned _agregado, Address _morada, string _pacotesComprados, int _total)
{
	nome = _nome;
	nif = _nif;
	agregado = _agregado;
	morada = _morada;
	pacotesComprados = _pacotesComprados;
	total = _total;
}

//Metodos GET

int Cliente::getNIF()
{
	return nif;
}

unsigned Cliente::getAgre()
{
	return agregado;
}

Address Cliente::getMorada()
{
	return morada;
}

string Cliente::getNome()
{
	return nome;
}

string Cliente::getPac()
{
	return pacotesComprados;
}

int Cliente::getTotal()
{
	return total;
}

vector<int> Cliente::getVectorPack()
{
	istringstream pacotes(pacotesComprados);
	string temp;
	vector<int> result;

	if (pacotesComprados == "-")					//verifica se o cliente comprou nenhum pacote
	{
		return result;
	}
	while (getline(pacotes, temp, ';'))				//enquanto houver pacotes
	{
		result.push_back(stoi(temp));
	}

	return result;

}



//Metodos SET

void Cliente::setNome(string _nome)
{
	nome = _nome;
}

void Cliente::setAgre(unsigned _agregado)
{
	agregado = _agregado;
}

void Cliente::setMorada(Address _morada)
{
	morada = _morada;

}

void Cliente::setNIF(int _nif)
{
	nif = _nif;
}

void Cliente::setPac(string _pacotesComprados)
{
	pacotesComprados = _pacotesComprados;
}

void Cliente::setTotal(int _total)
{
	total = _total;
}




ostream& operator<<(ostream& out, const Cliente &client)
{
	return out << "Nome:  " << client.nome << endl
				<< "Nif:  " << client.nif << endl
				 << "Agregado:  " << client.agregado << endl
				 << "Morada:  " << client.morada.getAddressFormated() << endl
				 << "Pacotes Comprados:  " << client.pacotesComprados << endl
				 << "Total:  " << client.total;
}



bool &operator < (Cliente &c1, Cliente &c2)
{
	bool result = c1.nif < c2.nif;

	return result;

}



