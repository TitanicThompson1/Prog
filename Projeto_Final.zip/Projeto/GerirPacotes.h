#pragma once
#include"Packet.h"
#include"Date.h"

//Fun��es para gerir pacotes



/*@Permite que utilizador crie pacote
@param last_pack_created � o Id do �ltimo pacote criado da ag�ncia!
@return um objecto Packet da classe Packet */
int criarPacote(Packet &pack, int las_pack_created);

/*@Permite apagar um pacote pelo utilizador ao identificar por Id qual o que pretende apagar
@param vector de pacotes de onde apagaremos um
@return vector alterado sem o pacote que era suposto eliminar*/
int eliminaPacote(vector<Packet> &packs);

/*@Alterar informa��es de pacote
@pacotes estar�o sempre pela ordem de id, de forma crescente de um em um
@Assim no vector de pacotes, pacote com abs(id) == x est� na posi��o do vector x -1!!
@ param packs � um vector de pacotes
*/
int alterarPacote(vector<Packet> &packs);