#pragma once

#include <iostream>
#include <string>
#include <sstream>
#include <vector>

using namespace std;

class Address
{

 private:
  string street; // street name
  unsigned short doorNumber; // door number
  string floor; // floor number ("-" is not applicable)
  string postalCode; // postal code
  string location; // site

 public:
  Address();
  Address(string street, unsigned short doorNumber, string floor, string postalCode, string location);

  // metodos GET
  string getStreet() const;
  unsigned short getDoorNumber() const;
  string getFloor() const;
  string getPostalCode() const;
  string getLocation() const;

  //formata a morada para uma string
  string getAddressFormated() const;
  
  // metodos SET 
  void setAddress(string street, unsigned short doorNumber, string floor, string postalCode, string location);			
  void setStreet(string street);			
  void setDoorNumber(unsigned short doorNumber);	
  void setFloor(string floor);
  void setPostalCode(string postalCode);
  void setLocation(string  location);

  // outros */
  
  //Apartir de uma string com a morada devidamente formatada, extrai os valores presentes na string para o objeto
  void getAddressFromString(string morada);

  // permite fazer cout da agencia num formato definido
  friend ostream& operator<<(ostream& out, const Address &address);



};
