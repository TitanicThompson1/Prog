﻿#include <iostream>
#include "clientes.h"
#include "Packet.h"
#include "Date.h"
#include "Address.h"
#include <map>
#include <iterator>
#include <unordered_map>
#include <algorithm>
#include "sort.h"
#include <utility>
#include "procura.h"


using namespace std;

//criar função para ordenar lugares por número de visitas




int mostVisitedPlaces(vector<Packet> packets) {

	unsigned number_places;

	//Mapa para guardar locais e número de visitas total!!!
	unordered_map<string, int> places;

	//Contar pacotes vendidos para cada local e associar
	for (size_t i = 0; i < packets.size(); i++) {

		for (size_t e = 0; e < packets.at(i).getPlaces().size(); e++) {

			//construtor padrão do mapa é efectuado, evitando assim que se um local ainda não existir no mapa, podemos acaumular o valor SoldSeats sem erros!!
			places[packets.at(i).getPlaces().at(e)];

			//acumular número de visitas por Local
			places[packets.at(i).getPlaces().at(e)] += packets.at(i).getSoldSeats();
		}


	}

	//Passar pares de locais com total de visitas para um vector
	vector<pair<string, int>> ordered_places;

	for (auto i = places.begin(); i != places.end(); i++) {
		pair <string, int> aux;

		aux.first = i->first;
		aux.second = i->second;
		ordered_places.push_back(aux);

	}

	// ordenamos os lugares por número de visitas 
	sort(ordered_places.begin(), ordered_places.end(), sortPlacesVisited);

	//Obter pesquisa dos N locais pretendidos
	cout << "Insira o número de locais mais visitados que pretende: ";
	cin >> number_places;

	while (!cin || number_places == 0 || number_places > ordered_places.size()) {

		if (number_places == 0) {

			//alterar Ricardo
			return -1;
		}//Caso em que número de locais mais visitados pedido, ultrapassa os disponíveis!
		else if (number_places > ordered_places.size()) {

			cerr << "O numero de locais mais visitados que pretende, ultrapassa o numero de locais possiveis! Insira outro valor: ";
			cin >> number_places;

		}
		else {//valores inválidos
			cerr << "Valor invalido! Tente novamente: ";
			cin.clear();
			cin.ignore(1000, '\n');
			cin >> number_places;
		}

	}


	//obter os N lugares pretendidos por números de visitas de forma descendente 
	for (size_t i = 0; i < number_places; i++) {

		cout << ordered_places.at(i).second << "-" << ordered_places.at(i).first << endl;
	}

	//alterar ricardo!!!
	return 0;
}

//Para usar no  clientsRecomendation
vector<pair<string, int>> mostVisitedPlaces(vector<Packet> packets, int n) {



	unordered_map<string, int> places;

	//Contar pacotes vendidos para cada local e associar
	for (size_t i = 0; i < packets.size(); i++) {

		for (size_t e = 0; e < packets.at(i).getPlaces().size(); e++) {

			//construtor padrão do mapa é efectuado, evitando assim que se um local ainda não existir no mapa, podemos acaumular o valor SoldSeats sem erros!!
			places[packets.at(i).getPlaces().at(e)];

			//acumular número de visitas por Local tendo em conta os vários pacotes
			places[packets.at(i).getPlaces().at(e)] += packets.at(i).getSoldSeats();

		}


	}

	//Passar pares de locais com total de visitas para um vector
	vector<pair<string, int>> ordered_places;

	for (auto i = places.begin(); i != places.end(); i++) {
		pair <string, int> aux;

		aux.first = i->first;
		aux.second = i->second;
		ordered_places.push_back(aux);

	}

	// ordenamos os lugares por número de visitas 
	sort(ordered_places.begin(), ordered_places.end(), sortPlacesVisited);

	//obter os N lugares pretendidos por números de visitas de forma descendente 
	for (size_t i = 0; i < n; i++) {

		cout << ordered_places.at(i).second << "-" << ordered_places.at(i).first;
	}


	return ordered_places;
}

vector<pair<string, int>> mostVisitedPlaces1(vector<Packet> packets, int n) {



	unordered_map<string, int> places;

	//Contar pacotes vendidos para cada local e associar
	for (size_t i = 0; i < packets.size(); i++) {

		for (size_t e = 0; e < packets.at(i).getPlaces().size(); e++) {

			//construtor padrão do mapa é efectuado, evitando assim que se um local ainda não existir no mapa, podemos acaumular o valor SoldSeats sem erros!!
			places[packets.at(i).getPlaces().at(e)];

			//acumular número de visitas por Local tendo em conta os vários pacotes
			places[packets.at(i).getPlaces().at(e)] += packets.at(i).getSoldSeats();

		}


	}

	//Passar pares de locais com total de visitas para um vector
	vector<pair<string, int>> ordered_places;

	for (auto i = places.begin(); i != places.end(); i++) {
		pair <string, int> aux;

		aux.first = i->first;
		aux.second = i->second;
		ordered_places.push_back(aux);

	}

	// ordenamos os lugares por número de visitas 
	sort(ordered_places.begin(), ordered_places.end(), sortPlacesVisited);


	return ordered_places;
}

int clientsRecomendation(vector<Packet> &packs, vector<Cliente> &clients) {

   vector<pair<string, int>> ordered_places;
   // número de locais mais visitados que utilizaremos como referencia nas recomendações
   int n;

   cout << "Introduza o numero de locais mais visitados pretendidos, para recomendar aos clientes:";
   cin >> n;



   while (!cin || n == 0 || n < 0) {
      if (n == 0) {

         // alterar ricardo!
         return -1;
      }
      else {
         cin.clear();
         cin.ignore(1000, '\n');

         cout << "Valor introduzido invalido! Tente novamente: ";
         cin >> n;

      }
   }

   ordered_places = mostVisitedPlaces1(packs, n);

   //Recomendações aos clientes
   //Usar multimap?!?!?

   //multimap para ter informação  de cada local como key  Id como elemento 
   multimap<string, int> places_id;

   for (int i = 0; i < packs.size(); i++) {
      //sítios a visitar por pacote
      vector<string> places = packs.at(i).getPlaces();
      //sítios a visitar por pacote
      int id = packs.at(i).getId();
      //Adicionar ao multimap pack_places key place -> element pack Id(podem haver keys com mais de um elemento == multimap)
      for (int e = 0; e < places.size(); e++) {
         //Adicionar place -> ID ao multimap
         places_id.insert({ places.at(e), id });

      }
   }

   //criar multimap com pacotes como key e lugares como elemento
   multimap<int, string> id_places;

   for (int i = 0; i < packs.size(); i++) {
      //sítios a visitar por pacote
      vector<string> places = packs.at(i).getPlaces();
      //sítios a visitar por pacote
      int id = packs.at(i).getId();
      //Adicionar ao multimap pack_places key place -> element pack Id(podem haver keys com mais de um elemento == multimap)
      for (int e = 0; e < places.size(); e++) {
         //Adicionar Id -> places ao multimap
         string place;
         place = places.at(e);

         id_places.insert({ id, place });

      }
   }


   //Imprimir grelha formatada
   cout << setw(40) << left << "Nome"<<  left << setw(20) << "NIF" << left << setw(60) << "Pacote recomendado"  << endl;

   //Achar recomendação para cada cliente
   for (int i = 0; i < clients.size(); i++) {

      //Uso de multimap auxiliar, para utilizar conteúdo do multimap places_id sem o alterar
      multimap<string, int> aux_places_id;
      //Uso de multimap auxiliar, para utilizar conteúdo do multimap id_places sem o alterar
      multimap<int, string> aux_id_places;

      aux_places_id = places_id;
      aux_id_places = id_places;

      //eliminar os locais -> id do multimap ficando apenas com os locais ->id que não visitou no multimap auxiliar

      // vector auxiliar com todos os pacotes comprados de cada cliente
      vector<int >aux_clients_packs = clients.at(i).getVectorPack();//ricardo vai passar para inteiros
      //vector auxiliar para guardar lugares visitados pelo cliente
      vector<string> client_visited_places;


      //Achar locais visitados por cada cliente, tendo em conta os pacotes comprados
      for (int e = 0; e < aux_clients_packs.size(); e++) {
         
         /*apagamos Lugares visitados no multimap aux_places_id( places-> Id)  da seguinte forma:
         usando Id dos pacotes comprados por cada cliente como chave
         no multimap aux_Id_places , onde guardaremos todos os lugares visitados
         por cada cliente num vector auxiliar. Usando por fim esse vector para apagar os lugares -> Id visitados no multimap places_id!!*/

         //Verificar pares pack -> places para um dado id, evito percorrer o mapa todo!!!!
         auto range = aux_id_places.equal_range(aux_clients_packs.at(e));
         
         //Obtenção de vector com os sítios visitados por cada cliente
         for (auto its = range.first; its != range.second; ++its) {
            //Obter locais visitados usando Id dos pacotes vendidos por cliente no multimap aux_id_places
            if (its->first == aux_clients_packs.at(e)) {
               client_visited_places.push_back(its->second);


            }


         }
      }


      //apagar no multimap aux_places_id (places ->) lugares visitados pelo cliente
      for (int e = 0; e < client_visited_places.size(); e++) {
         aux_places_id.erase(client_visited_places.at(e));

      }


      //Recomendação de clientes, recomendando por lugar mais visitado por ordem descendente dos N lugares mais visitados pretendidos

      //N lugares mais visitados

      //Id do possível pack recomendado
      int pack_recomended = 0;

      //Verificar se lugar -> pack para recomendar apenas se tem lugares suficientes para possível compra!
      bool flag_pack = false;

      //index do pack que tentaremos encontrar!
      int index_pack_recomended = 0;

      //Procurar pack que visite Um dos N lugares mais visitados sempre por ordem descendente
      for (int e = 0; e < n; e++) {
         string aux = ordered_places.at(e).first;

         auto range = aux_places_id.equal_range(aux);

         for (auto its = range.first; its != range.second; ++its) {
            //pacote que será recomendado por ordem de lugares mais visitados
            if (its->first == aux) {


               pack_recomended = its->second;

               //Verificar disponibilidade do pacote em relação ao id negativo(pacote indisponível ou lugares disponíveis insuficientes

               index_pack_recomended = procuraPosPacote(packs, 0, abs(pack_recomended));

               //Pacote válido para ser recomendado!



            }
         }
         if (packs.at(index_pack_recomended).getSoldSeats() + clients.at(i).getAgre() <= packs.at(index_pack_recomended).getMaxPersons() && pack_recomended > 0) {
            //podemos sair do ciclo que procura os pacotes para os N locais mais visitados
            flag_pack = true;
            break;

         }


      }


         //verificar e imprimir se temos pack válido
         if (flag_pack) {

            cout << setw(40) << left << clients.at(i).getNome()  << left << setw(20) << clients.at(i).getNIF() << setw(60) << pack_recomended << endl;
            //podemos sair do ciclo que vai procurar os pares place -> pack nos N mais visitados

         }





         //Após verificar nos N sítios mais visitados:
         if (flag_pack == false) {
            // Imprime que não encontramos um pacote nos N destinos mais visitadoss tendo em conta as condições de disponibilidade, número de lugares e os N locais amis visitados como limitação

            cout << setw(40) << left << clients.at(i).getNome() << left << setw(20) << (clients.at(i).getNIF())  <<  "Sem pacotes para recomendar tendo em conta os " << n << " locais mais visitados,lugares disponiveis ou disponibilidade!" << endl;

         }

      




      }


      return 0;
      
   }
   
