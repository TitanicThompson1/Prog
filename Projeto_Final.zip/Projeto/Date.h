#pragma once

#include <iostream>
#include <string>
#include <vector>
#include <iomanip>
#include <fstream>
#include <sstream>

using namespace std;

class Date {

private:
	unsigned short day;
	unsigned short month;
	unsigned year;

public:

	//Constructors
	Date();
	Date(string date);
	Date(unsigned short day, unsigned short month, unsigned year);

	// GET methods
	unsigned short getDay() const;
	unsigned short getMonth() const;
	unsigned getYear() const;

	// SET methods
	void setDay(unsigned short day);
	void setMonth(unsigned short month);
	void setYear(unsigned year);


	// other methods 

	/*
	@Fun��o para inserir datas num determinado contexto retornando um objecto da classe Date
	@return objecto do tipo data
	*/
	void insertDate();

	/*
	@Verifica se data � v�lida para os meses, dias e anos e regras inerentes
	   @return false se � inv�lida e true se � v�lida
	*/
	bool validDate();

	//formata o cout
	friend ostream& operator<<(ostream& out, const Date & date);

	//Instrui em como efectuar a operacao ==
	friend bool operator==(const Date& d1, const Date& d2);

	//Instrui em como efectuar a operacao <
	friend bool operator<(const Date& begin, const Date& end);

	//Instrui em como efectuar a operacao >
	friend bool operator>(const Date& begin, const Date& end);

	friend bool operator<=(const Date& begin, const Date& end);

	friend bool operator>=(const Date& begin, const Date& end);

};