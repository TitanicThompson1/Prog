#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <algorithm>

#include "clientes.h"
#include"Packet.h"
#include"Date.h"
#include "inAndOut.h"
#include "sort.h"

using namespace std;

/*@Verifica se informa��o no ficheiro referente aos pacotes cumpre :
@Se ficheiro tem informa��o completa sobre n pacotes tur�sticos
 usamos o facto de que informa��o referente a um pacote utiliza sempre 7 linhas do ficheiro
 por cada 7 linhas/pacote teremos uma linha com o separador de clientes usado
 por cada n pacotes, teremos n-1 separadores(::::::::::) 7*n linhas e 1 linha com a informa��o sobre �ltimo pacote criado*/
void verificarInforma��oPacotes(ifstream &packs_file);

/*
@Importa de um ficheiro todos os clientes;
nome_ficheiro: nome do ficheiro que se pretende importar;
RETURN: um vector que contem todos os clientes;
*/
vector<Cliente> importaTodosClientes(string nome_ficheiro);

/*@Importa de um ficheiro todos os pacotes
@param nome_ficheiro � o ficheiro do qual importamos pacotes
@return um vector com todos os objectos da Class Packet*/
vector<Packet> importaPacotes(string nome_ficheiro);

/*@Exporta para um ficheiro objectos da classe Packet
@param packs � o vector a ser exportado
@param nome_ficheiro
*/
void exportaPacotes(vector<Packet> packs, string nome_ficheiro);

/*
@Exporta para um ficheiro todos os clientes;
clients: vector que cont�m todos os clientes;
nome_ficheiro: nome do ficheiro que se pretende importar;
RETURN: void
*/
void exportaTodosClientes(vector<Cliente> clients, string nome_ficheiro);

