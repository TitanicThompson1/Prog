#pragma once
#include <iostream>
#include <time.h>
#include <vector>
#include <string>
#include <fstream>

using namespace std;

void gerar();

vector<string> vetorNomes();

vector<string> vetorLocais();

vector<int> vetorInteiros();

vector<int> vetorNIF();