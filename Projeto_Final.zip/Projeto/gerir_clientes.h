#pragma once
#include <iostream>
#include <string>

#include "verificacao.h"
#include "clientes.h"
#include "procura.h"
#include "Address.h"
#include "get_out.h"
#include "sort.h"

using namespace std;

/*
@adiciona um cliente a um vetor de clientes
clients: vector de clientes
RETURN: -1 se o utilizador cancelou; 0 caso contrario
*/
int adicionaCliente(vector<Cliente> &clients);

/*
@elimina um cliente de um vetor de clientes
clients: vector de clientes
nif: nif do cliente a eliminar
RETURN: void
*/
void eliminaCliente(vector<Cliente> &clients, int nif);

/*
@altera um campo de um cliente de um vetor de clientes
clients: vector de clientes
RETURN: -1 se o utilizador cancelou; 0 caso contrario
*/
int alterarCliente(vector<Cliente> &clients);
