#pragma once
#include <iostream>
#include <vector>

#include "Packet.h"
#include "clientes.h"

/*
@Efetua a compra de um pacote;
packs: pacote a comprar;
clients: cliente que pretende comprar o pacote;
RETURN: 0, se a operacao comprar for bem sucedida; 1 caso contrario;
*/
int compra_pacote(Packet &packs, Cliente &clients);

/*
@Calcula e p�e para a consola o valor total e o numero de pacotes vendidos;
packs: vetor dos pacotes;
clients: vetor dos clientes;
RETURN: void;
*/
void total(vector<Packet> packs, vector<Cliente> clients);
