#pragma once
#include <iostream>
#include <vector>
#include <fstream>
#include <string>

#include "clientes.h"
#include "Packet.h"
#include "inAndOut.h"


using namespace std;

class Agencia 
{
public:
	//Constructors
	Agencia();
	Agencia(string nome_ficheiro);

	//importa uma agencia de um ficheiro
	void importaAgencia(string nome_ficheiro);
	
	//Metodos GET
	string getClients();						
	string getPacks();							
	bool getClientsFlag();
	bool getPacotesFlag();
	vector<Cliente> &getVectorClient();			//retorna o vector que contem todos os clientes
	vector<Packet> &getVectorPack();			//retorna o vector que contem todos os pacotes


	void UpdateClientsFlag(bool flag=true);				//atualiza o valor da flag dos clientes
	void UpdatePacotesFlag(bool flag=true);				//atualiza o valor da flag dos pacotes

	//Destructor
	~Agencia();

	// formatacao do cout
	friend ostream& operator<<(ostream& out, const Agencia &agency);

private:
	string nome;
	int nif;
	string url;
	string morada;
	string fich_clientes;				//nome do ficheiro de clientes
	string fich_pacotes;				//nome do ficheiro de pacotes
	vector<Cliente> clients;
	vector<Packet> packs;

	bool FlagPacotes;								//indica se o vetor dos pacotes foi alterado
	bool FlagClientes;								//indica se o vetor dos clientes foi alterado

};