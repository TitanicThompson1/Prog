
#include "Packet.h"
#include"Date.h"

#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>


Packet::Packet() {

	//ver melhor isto!!!
	id = 0;
	vector<string> aux;
	places = aux;

	begin = Date();
	end = Date();
	pricePerPerson = 0;
	maxPersons = 0;
	soldSeats = 0;


}
Packet::Packet(int id, vector<string> &places, Date begin, Date end, double pricePerPerson, unsigned maxPersons, unsigned soldSeats) {
	//Adicionar atributos a um objecto da classe Packet
	this->id = id;
	this->places = places;
	this->begin = begin;
	this->end = end;
	this->pricePerPerson = pricePerPerson;
	this->maxPersons = maxPersons;
	this->soldSeats = soldSeats;
}



// metodos GET

/*Obter identificador*/
int Packet::getId() const {

	return id;

}

vector<string> Packet::getPlaces() const {
	//ver melhor este m�todo!

	return places;
}

Date Packet::getBeginDate() const {

	return begin;

}

Date Packet::getEndDate() const {

	return end;
}

double Packet::getPricePerPerson() const {

	return pricePerPerson;
}

unsigned Packet::getMaxPersons() const {

	return maxPersons;
}


unsigned Packet::getSoldSeats() const {
	return soldSeats;
}


// metodos SET

void Packet::setId(unsigned id) {

	this->id = id;
}

void Packet::setPlaces(vector<string> &places) {

	this->places = places;
}

void Packet::setBeginDate(Date begin) {

	this->begin = begin;;
}

void Packet::setEndDate(Date end) {

	this->end = end;

}

void Packet::setPricePerPerson(double pricePerPerson) {

	this->pricePerPerson = pricePerPerson;
}

void Packet::setMaxPersons(unsigned maxPersons) {

	this->maxPersons = maxPersons;
}

void Packet::setSoldSeats(unsigned soldSeats) {
	this->soldSeats = soldSeats;
}


/*********************************
 * Other methods
 ********************************/


 /*********************************
 * M�todos referentes aos s�tios a visitar dos pacotes
 ******************************** */


string Packet::getPlacesFormated() const
{
	cout << setfill(' ');
	string result = "";

	if (places.size() == 1) {
		result += places.at(0);

	}
	else {
		result += places.at(0) + " - ";
		for (int i = 1; i < places.size() - 1; i++) {
			result += places.at(i) + ", ";

		}
		result += places.at(places.size() - 1);


	}

	return result;

}



vector<string> Packet::getPlacesFromString(string places) {

	istringstream aux_places(places);

	vector<string> result;

	getline(aux_places, places, '-');

	if (aux_places.eof())
	{
		result.push_back(places);
		return result;
	}

	//elimina o espaco no fim
	places = places.substr(0, places.size() - 1);
	result.push_back(places);
	while (getline(aux_places, places, ','))
	{

		//elimina o espaco no inicio
		places = places.substr(1, places.size());
		result.push_back(places);
	}

	return result;
}



/*********************************
 * Show Packet information
 ********************************/



 /*@Define como informa��o sobre pacotes ser� apresentada usando operador <<
 @param  out � um objecto output stream que permite escrever caracteres entre outras coisas
 @ param packet � o pacote do qual queremos obter informa��o usando o operador <<
 @ return a informa��o referente ao pacote da forma que pretendemos*/
ostream& operator<<(ostream& out, const Packet &packet) {


	return out << packet.id << endl << packet.getPlacesFormated() << endl << packet.begin << endl << packet.end << endl << packet.pricePerPerson << endl << packet.maxPersons << endl << packet.soldSeats;


}


bool& operator < (Packet& pack1, Packet& pack2) {

	bool result;
	result = abs(pack1.getId()) < abs(pack2.getId());

	return result;
}


