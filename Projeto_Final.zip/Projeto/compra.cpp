#include <iostream>
#include <vector>

#include "Packet.h"
#include "clientes.h"
#include "procura.h"

using namespace std;

int compra_pacote(Packet &pack, Cliente &client)
{

	if (procuraPosPacoteComprados(client.getVectorPack(),pack.getId()) != -1)					//verifica se o cliente j� comprou o pacote
	{
		return 1;
	}
	
	pack.setSoldSeats(pack.getSoldSeats() + client.getAgre());									//atualiza o numero de lugares vendidos

	string novo_valor;
	
	if (client.getVectorPack().empty())															//verifica se o cliente j� comprou algum pacote
	{

		client.setPac(to_string(pack.getId()));													//atualiza os pacotes comprados

	}
	else
	{
		novo_valor = client.getPac() + " ; " + to_string(pack.getId());							//adiciona o novo pacote aos pacotes j� comprados
		client.setPac(novo_valor);																//atualiza os pacotes comprados
	}
	if (pack.getSoldSeats() == pack.getMaxPersons())											//verifica se o pacote j� est� esgotado
	{														
		pack.setId(-pack.getId());																
	}

	// atualiza o total do cliente

	client.setTotal(pack.getPricePerPerson()*client.getAgre() + client.getTotal());

	return 0;

}

void total(vector<Packet> packs, vector<Cliente> clients)
{

	int total_monetario = 0, total_pacs = 0;
	int pos_pacote, ola1, ola2;
	vector<int> temp;

	for (int i = 0; i < clients.size(); i++)							//percorre o vetor dos clientes
	{

		total_monetario += clients.at(i).getTotal();					//calcula o total monetario adicionando o total de cada cliente
		temp = clients.at(i).getVectorPack();
		ola2 = clients.at(i).getAgre();
		total_pacs += clients.at(i).getVectorPack().size()*clients.at(i).getAgre();			//calcula o numero de pacotes vendidos
	}

	cout << "Numero total de pacotes vendidos:  " << total_pacs << endl;
	cout << "Valor total de pacotes vendidos:  " << total_monetario << endl;

}