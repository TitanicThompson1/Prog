#include "gerir_clientes.h"


int adicionaCliente(vector<Cliente> &clients)
{
	cout << "(Introduza 0 em qualquer momento para cancelar)" << endl << endl;

	string nome, pacotes, rua, andar, codpos, loc, num;
	unsigned agregado;
	int nif;
	string dec;
	Cliente temp;

	cin.ignore();
	cout << "Nome:  "; getline(cin, nome);
	if (nome == "0")
	{
		return -1;
	}
	cout << "NIF:  "; cin >> nif;
	

	//verifica se o input � invalido ou se o nif j� existe ou se n�o tem 9 digitos;
	// repete at� ter um nif valido
	while (cin.fail() || verifica_NIF(nif) != 9 || procuraPosCliente(clients,nif) != -1)		
	{								
		if (nif == 0 && !cin.fail())
		{
			return -1;
		}
		cin.clear();																						
		cin.ignore(1000, '\n');			
		
		if (procuraPosCliente(clients, nif) != -1) {
			cerr << "NIF ja existente. Por favor introduza um NIF:  "; cin >> nif;							
		}																									
		else {																								
																											
			cerr << "NIF invalido. Por favor introduza um NIF:  "; cin >> nif;								
		}																								
	}																										

	cout << "Numero de pessoas no agregado familiar:  "; cin >> agregado;	
	
	//verifica se o input � invalido ou se o utilizador deseja cancelar
	while (cin.fail() || agregado == 0 || agregado == 4294967295)
	{
		if (agregado == 0 && !cin.fail())			// a condicao !cin.fail() � necessaria uma vez que se o utilizador introduzir um caracter, como agregado � um int, far� que o agregado seja igual a 0, cancelando assim a opera��o de acidiocar, o que n�o � o desejado;
		{
			return -1;
		}
		else
		{
			cin.clear();
			cin.ignore(100, '\n');
			cerr << "Erro: Numero invalido. Por favor volte a introduzir:  "; cin >> agregado;
		}
	}
	

	cout << "Rua:  ";
	cin.ignore();						
	getline(cin, rua);

	//verifica se o utilizador deseja cancelar
	if (rua == "0")
	{
		return -1;
	}

	cout << "Numero da porta:  ";
	cin >> num;

	//verifica se o utilizador deseja cancelar
	if (num == "0")
	{
		return-1;
	}

	cout << "Apartamento ( '-' se viver numa casa):  "; cin >> andar;


	//verifica se o utilizador deseja cancelar
	if (andar == "0")
	{
		return -1;
	}

	cout << "Codigo-Postal:  "; cin >> codpos;

	//verifica se o utilizador deseja cancelar
	if (codpos == "0")
	{
		return -1;
	}

	cout << "Localidade:  ";
	cin.ignore();
	getline(cin, loc);

	//verifica se o utilizador deseja cancelar
	if (loc == "0")
	{
		return -1;
	}

	Address morada(rua, stoi(num), andar, codpos, loc);
	
	temp.addCliente(nome, nif, agregado, morada);

	system("cls");

	//confirma que o utilizador quer adicionar o cliente
	dec = confirmarCliente(temp, "Deseja adicionar este cliente? Introduza S(Sim) ou N(Nao)");

	if (dec == "S")
	{
		clients.push_back(temp);
		return 0;
	}
	else
	{
		return -1;
	}
	
}

void eliminaCliente(vector<Cliente> &clients, int nif)
{
	vector<Cliente>::iterator cPtr = clients.begin();
	int pos_cliente = 0;

	pos_cliente = procuraPosCliente(clients, nif);				//encontra o cliente

	clients.erase(cPtr + pos_cliente);							//elimina o cliente
	
}

int alterarCliente(vector<Cliente> &clients)
{

	int campo_a_alterar;
	string valor;
	int nif;
	string rua, andar, codpos, loc, morada, num, dec_str;
	int int_valor;
	unsigned un_valor;
	Cliente temp;
	int c;																									//posicao do cliente no vetor
	Address temp2;


	cout << "Introduza o nif do cliente:  "; cin >> nif;

	c = procuraPosCliente(clients, nif);

	//verifica se o Cliente nao existe ou se o input � invalido
	while (c == -1 || cin.fail()) {	

		if (nif == 0 && !cin.fail())
		{
			return -1;
		}

		cin.clear();																								//Verifica se o NIF introduzido est� 
		cin.ignore(1000, '\n');																						//associado a um cliente.
	
		cerr << "Erro: o cliente em questao nao existe. Por favor introduza um numero valido:  "; cin >> nif;
		c = procuraPosCliente(clients, nif);
	}
	system("cls");
	
	cout << "Campo a alterar:  "
		<< endl << "1 - Nome "
		<< endl << "2 - NIF "
		<< endl << "3 - Agregado "
		<< endl << "4 - Morada " << endl;

	cin >> campo_a_alterar;

	// verifica se o campo a alterar n�o est� entre 1 e 4 ou se o input � invalido
	while (cin.fail() || campo_a_alterar <=0 || campo_a_alterar>4 ) {												
		
		if (campo_a_alterar == 0 && !cin.fail())
		{
			return -1;
		}
		cin.clear();																								
		cin.ignore(1000, '\n');				
		
		cerr << "Numero invalido. Introduza um numero entre 1 a 4:  ";												
		cin >> campo_a_alterar;																						
	}




	switch (campo_a_alterar)
	{

	case 1:

		cout << "Introduza o valor:  "; cin >> valor;

		//verifica se o utilizador quer cancelar
		if (valor == "0")
		{
			return -1;
		}
		system("cls");

		//verifica se o utilizador quer continuar
		dec_str = confirmarCliente(clients.at(c), "Deseja alterar este cliente? Introduza S(Sim) ou N(Nao)");

		if (dec_str == "S")
		{
			clients.at(c).setNome(valor);

		}
		else
		{
			return -1;
		}

		break;
	case 2:

		cout << "Introduza o valor:  "; cin >> int_valor;

		//verificase o nif � valido, se j� existe
		while (verifica_NIF(int_valor) != 9 || procuraPosCliente(clients, int_valor) != -1 || cin.fail())		
		{		

			//verifica se o utilizador quer cancelar
			if (int_valor == 0 && !cin.fail())
			{
				return -1;
			}
																																//caso seja este o campo a alterar
			if (verifica_NIF(int_valor) != 9 || cin.fail()) {
				cin.clear();
				cin.ignore(100, '\n');
				cerr << "Erro. NIF nao valido. Introduza novamente:  "; cin >> int_valor;
			}
			else if (procuraPosCliente(clients, int_valor) != -1) {

				cerr << "NIF ja existente. Por favor introduza outro NIF:  "; cin >> int_valor;
			}
		}

		system("cls");

		//verifica se o utilizador quer continuar
		dec_str = confirmarCliente(clients.at(c), "Deseja alterar este cliente? Introduza S(Sim) ou N(Nao)");

		if (dec_str == "S")
		{
			clients.at(c).setNIF(int_valor);
			sort(clients.begin(), clients.end(), sort_clients);


		}
		else
		{
			return -1;
		}

		break;
	case 3:

		cout << "Introduza o valor:  "; cin >> un_valor;

		while (cin.fail() || un_valor == 0 || un_valor == 4294967295)
		{
			//verifica se o utilizador quer cancelar
			if (un_valor == 0 && !cin.fail())
			{
				return -1;
			}
			cin.clear();
			cin.ignore();
			cerr << "Erro: Valor invalido. Introduza um valor valido"; cin >> un_valor;
		}

		


		system("cls");

		//verifica se o utilizador quer continuar
		dec_str = confirmarCliente(clients.at(c), "Deseja alterar este cliente? Introduza S(Sim) ou N(Nao)");

		if (dec_str == "S")
		{
			clients.at(c).setAgre(un_valor);

		}
		else
		{
			return -1;
		}
		
		break;
	case 4:

		cout << "Rua:  ";																							//pede a morada
		cin.ignore();
		getline(cin, rua);

		//verifica se o utilizador quer cancelar
		if (rua == "0")
		{
			return -1;
		}

		cout << "Numero da porta:  ";
		cin >> num;

		//verifica se o utilizador quer cancelar
		if (num == "0")
		{
			return -1;
		}

		cout << "Apartamento ( '-' se viver numa casa):  "; cin >> andar;

		//verifica se o utilizador quer cancelar
		if (andar == "0")
		{
			return -1;
		}

		cout << "Codigo-Postal:  "; cin >> codpos;

		//verifica se o utilizador quer cancelar
		if (codpos == "0")
		{
			return -1;
		}

		cout << "Localidade:  ";

		cin.ignore();
		getline(cin, loc);

		//verifica se o utilizador quer cancelar
		if (loc == "0")
		{
			return -1;
		}

		system("cls");

		//verifica se o utilizador quer continuar
		dec_str = confirmarCliente(clients.at(c), "Deseja alterar este cliente? Introduza S(Sim) ou N(Nao)");

		if (dec_str == "S")
		{
			temp2.setAddress(rua, stoi(num), andar, codpos, loc);
			clients.at(c).setMorada(temp2);

		}
		else
		{
			return -1;
		}

		
		break;
	default:
		break;
	}
	return 0;
}
