#include "verificacao.h"


int verifica_NIF(int nif) {
	int digitos = 0;
	while (nif != 0) {

		nif = nif / 10;
		digitos++;
	}
	return digitos;
}

Agencia verifica_agencia(string nome_ficheiro)
{

	ifstream test_file(nome_ficheiro);													//Verifica se o ficheiro agencia existe
	if (!test_file.good())
	{
		cerr << "Erro: Ficheiro da agencia nao existe";
		exit(1);
	}
	test_file.close();

	Agencia agency(nome_ficheiro);


	test_file.open(agency.getClients());
	
	if (!test_file.good())																//Verifica se o ficheiro de clientes existe
	{
		cerr << "Erro: Ficheiro dos clientes nao existe";
		exit(1);
	}
	test_file.close();

	test_file.open(agency.getPacks());

	if (!test_file.good())																//Verifica se o ficheiro de pacotes existe
	{
		cerr << "Erro: Ficheiro dos pacotes nao existe";
		exit(1);
	}
	return agency;
}

