#pragma once
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

#include "agencia.h"
#include "clientes.h"
#include "gerir_clientes.h"
#include "get_out.h"
#include "formatacao.h"
#include "listagem.h"
#include "verificacao.h"
#include "procura.h"
#include "GerirPacotes.h"
#include "compra.h"
#include "sort.h"
#include "PacketInfoSeachr.h"

using namespace std;
/*
@Menu da Agencia
RETURN: proximo menu que se quer aceder ou sair do programa;
*/
int menuAgencia();

/*
@Menu de Clientes
RETURN: proximo menu que se quer aceder ou sair do programa;
*/
int menuClientes(Agencia& agency);

/*
@Menu de visualiza��o de Clientes
RETURN: proximo menu que se quer aceder ou sair do programa;
*/
int menuClientesVer(Agencia& agency);

/*
@Menu de Pacotes
RETURN: proximo menu que se quer aceder ou sair do programa;
*/
int menuPacotes(Agencia& agency);

/*
@Menu de visualiza��o de pacotes;
RETURN: proximo menu que se quer aceder ou sair do programa;
*/
int menuPacoteVer(Agencia& agency);

/*
@Menu de informa��es gerais
RETURN: proximo menu que se quer aceder ou sair do programa;
*/
int menuInfo(Agencia& agency);

/*
@Menu de Compra
RETURN: proximo menu que se quer aceder ou sair do programa;
*/
int menuComprar(Agencia& agency);

/*
@Menu das Estatisticas
RETURN: proximo menu que se quer aceder ou sair do programa;
*/
int menuEstatistica(Agencia& agency);
