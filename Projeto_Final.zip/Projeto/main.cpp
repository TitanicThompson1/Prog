#include <iostream>
#include <iomanip>
#include <fstream>

#include "clientes.h"
#include "inAndOut.h"
#include "gerir_clientes.H"
#include "formatacao.h"
#include "listagem.h"
#include "agencia.h"
#include "menus.h"
#include "verificacao.h"
#include "Address.h"
#include "procura.h"
#include "gerar.h"

using namespace std;

int main() 
{
	/*
   setlocale(LC_ALL, "");
   */
	string fich_agencia;					//nome do ficheiro da agencia
	
	cout << "Qual o nome do ficheiro da agencia a usar?  "; cin >> fich_agencia;
   
	Agencia agency;

	//Verifica se o ficheiro existe
	agency = verifica_agencia(fich_agencia);
	
	
	
	int dec = 0;
	
	
	
	
	while (dec > -1) {
		switch (dec)
		{
		case 0:

			//Vai para o menu Agencia
			dec = menuAgencia();
			break;
		
		case 1:

			//Vai para o menu Clientes
			dec = menuClientes(agency);
			break;
		
		case 2:

			//Vai para o menu Clientes Ver
			dec = menuClientesVer(agency);
			break;
		
		case 3:

			// Vai para o menu Pacotes
			dec = menuPacotes(agency);
			break;
		
		case 4:

			//Vai para o menu Pacote Ver
			dec = menuPacoteVer(agency);
			break;
		
		case 5:

			//Vai para o menu Comprar
			dec = menuComprar(agency);
			break;

		case 6:

			//Vai para o menu de Informacoes gerais
			dec = menuInfo(agency);
			break;
		case 7:

			//Vai para o menu das Estatistica
			dec = menuEstatistica(agency);
			break;

		default:
			break;
		}
	}
	
	//Verifica se o vetor dos clientes sofreu alguma alteracao
	if (agency.getClientsFlag()) 
		exportaTodosClientes(agency.getVectorClient(), agency.getClients());

	//Verifica se o vetor dos pacotes sofreu alguma alteracao
	if (agency.getPacotesFlag()) 
		exportaPacotes(agency.getVectorPack(), agency.getPacks());
	
		return 0;
}