#pragma once
#include <iostream>

#include "clientes.h"

using namespace std;

bool sort_clients(Cliente c1, Cliente c2);

bool sort_pacotes(Packet p1, Packet p2);

bool sortPlacesVisited(pair<string, int> place1, pair<string, int> place2);