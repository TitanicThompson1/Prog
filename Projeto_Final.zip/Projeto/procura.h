#pragma once

#include <iostream>

#include "Date.h"
#include "clientes.h"

/*
@Procura a posi��o em que o clientes est� no vector;
clients: vetor dos clientes;
_nif: nif do clientes que se pretende encontrar;
RETURN: a posicao do cliente, se o encontrar; -1 caso contrario;
*/
int procuraPosCliente(vector<Cliente> clients, int _nif);

/*
@Procura a posi��o em que o pacote est� no vector;
clients: vetor dos clientes;
minimum_left_position: posicao na qual se quer come�ar a pesquisa;
Id: id do pacote que se pretende encontrar
RETURN: a posicao do pacote, se o encontrar; -1 caso contrario;
*/
int procuraPosPacote(vector<Packet> &packs, int minimum_left_position, int Id);

/*
@Procura num vector um dado valor;
vetor: vector que se pretende pesquisar;
valor: valor que se quer encontrar;
RETURN: true se encontrar; false caso contrario
*/
template <typename T>
bool procuraValorVector(vector<T> vetor, T valor);

/*
@Procura todos os pacotes que tenham nos Principais locais turisticos um certo destino e imprime na consola;
packs: vector de pacotes;
destino: destino a pesquisar;
RETURN: void
*/
void procuraPorDestino(vector<Packet> packs, string destino);

/*
@Procura todos os pacotes que estejam entre duas datas e imprime na consola;
packs: vector de pacotes;
begin: data de inicio;
end: data de fim;
RETURN: void
*/
void procuraPorDatas(vector<Packet> packs, Date begin, Date end);

/*
@Procura todos os pacotes que tenham nos Principais locais turisticos um certo destino e entre duas datas e imprime na consola;
packs: vector de pacotes;
destino: destino a pesquisar;
begin: data de inicio;
end: data de fim;
RETURN: void
*/
void procuraPorDestinoEDatas(vector<Packet> packs, string destino, Date begin, Date end);

int procuraPosPacoteComprados(vector<int> packs, int id);

void procuraPacotesVendidos(vector<Packet> packs);


