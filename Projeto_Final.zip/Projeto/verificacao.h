#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>

#include "agencia.h"

using namespace std;

/*
@Determina quantos digitos tem o nif
nif: numero de identifica��o fiscal
RETURN: numero de digitos do nif
*/
int verifica_NIF(int nif);

/*
@Verifica se o ficheiro da agencia, dos clientes e dos pacotes existem;
nome_ficheiro: nome do ficheiro da ag�ncia;
RETURN: a agencia;
*/
Agencia verifica_agencia(string nome_ficheiro);