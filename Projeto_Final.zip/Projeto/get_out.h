#pragma once
#include "Packet.h"
#include "clientes.h"

using namespace std;

/*
@Mostra na consola as op��es que se pode realizar
n�o tem parametros de entrada
RETURN: 0 se o utilizador quiser voltar para o menu anterior, -1 se quiser sair do programa
*/
int opcao_a_realizar();
/*
@Pede para o utilizador confirmar a a�ao;
objeto: cliente que se pretende adicionar/eliminar/alterar;
mensagem: mensagem personalizada a apresentar ao utilizador;
RETURN: Uma string que contem "S" (se o utilizador confirmou) ou "N" (se o utilizador cancelou)
*/
string confirmarCliente(Cliente objecto, string mensagem);

/*
@Pede para o utilizador confirmar a a�ao;
objeto: pacote que se pretende adicionar/eliminar/alterar;
mensagem: mensagem personalizada a apresentar ao utilizador;
RETURN: Uma string que contem "S" (se o utilizador confirmou) ou "N" (se o utilizador cancelou)
*/
string confirmarPacote(Packet objecto, string mensagem);
