#pragma once

#include <iostream>
#include "clientes.h"
#include "Packet.h"
#include "Date.h"
#include "Address.h"


/*@Mostra nome sobre os N locais mais visitados entre todos os pacotes
@param packets � o vector de pacotes no qual procuraremos os locais
*/
int mostVisitedPlaces(vector<Packet> packets);

vector<pair<string, int>> mostVisitedPlaces(vector<Packet> packets, int n);

vector<pair<string, int>> mostVisitedPlaces1(vector<Packet> packets, int n);

int clientsRecomendation(vector<Packet> &pack, vector<Cliente> &clients);