#include "agencia.h"


Agencia::Agencia()
{
	nome = "DESCONHECIDO";
	nif = -1;
	url = "DESCONHECIDO";
	morada = "DESCONHECIDA";
	fich_clientes = "DESCONHECIDO";
	fich_pacotes = "DESCONHECIDO";
	FlagClientes = false;
	FlagPacotes = false;

}

Agencia::Agencia(string nome_ficheiro)
{
	string temp;
	ifstream infile(nome_ficheiro);

	getline(infile, temp);
	nome = temp;
	
	getline(infile, temp);
	nif = stoi(temp);
	
	getline(infile, temp);
	url = temp;
	
	getline(infile, temp);
	morada = temp;
	
	getline(infile, temp);
	fich_clientes = temp;
	
	getline(infile, temp);
	fich_pacotes = temp;

	infile.close();
	

	clients = importaTodosClientes(fich_clientes);

	packs = importaPacotes(fich_pacotes);

	FlagClientes = false;
	FlagPacotes = false;
	
}

void Agencia::importaAgencia(string nome_ficheiro)
{
	string temp;
	ifstream infile(nome_ficheiro);

	getline(infile, temp);
	nome = temp;

	getline(infile, temp);
	nif = stoi(temp);

	getline(infile, temp);
	url = temp;

	getline(infile, temp);
	morada = temp;

	getline(infile, temp);
	fich_clientes = temp;

	getline(infile, temp);
	fich_pacotes = temp;
	
	infile.close();

	clients = importaTodosClientes(fich_clientes);

	packs = importaPacotes(fich_pacotes);

}


//Metodos GET

string Agencia::getClients()
{
	return fich_clientes;
}

string Agencia::getPacks() 
{
	return fich_pacotes;
}

bool Agencia::getClientsFlag()
{
	return FlagClientes;
}

bool Agencia::getPacotesFlag()
{
	return FlagPacotes;
}

vector<Cliente> &Agencia::getVectorClient()
{
	return clients;

}

vector<Packet> &Agencia::getVectorPack()
{
	return packs;
}




void Agencia::UpdateClientsFlag(bool flag)
{
	FlagClientes = flag;
}

void Agencia::UpdatePacotesFlag(bool flag)
{
	FlagPacotes = flag;
}




Agencia::~Agencia() 
{
	//esta instrucao liberta a memoria previamente ocupada pelo vetor de clientes
	vector<Cliente>().swap(clients);

	//esta instrucao liberta a memoria previamente ocupada pelo vetor de pacotes
	vector<Packet>().swap(packs);
	
}

ostream& operator<<(ostream& out, const Agencia &agency){
	
	return out << "Nome:  " << agency.nome
		<< endl << "NIF:  " << agency.nif
		<< endl << "URL:  " << agency.url
		<< endl << "Morada:  " << agency.morada
		<< endl << "Nome do ficheiro dos clientes:  " << agency.fich_clientes
		<< endl << "Nome do ficheiro dos pacotes:  " << agency.fich_pacotes;
}