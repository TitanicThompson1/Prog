#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <iomanip>

#include "Packet.h"
#include "clientes.h"
#include "formatacao.h"
#include "procura.h"

using namespace std;


/*
@Lista a consola todos os clientes neste formato:
@"Nome_de_cliente" - "NIF_de_cliente"
clients: vector que contem os clientes
RETURN: void
*/
void lista_clientes_em_vector(vector<Cliente> clients);

/*
	@Lista na consola todos os pacotes neste formato:
	@"Numero_do_pacote" : "Localidades a visitar"
	nome_ficheiro: nome do ficheiro;
	RETURN: void
	*/
void lista_pacotes_em_vector(vector<Packet> packs);

void lista_pacotes_de_cliente(Cliente clients, vector<Packet> packs);

