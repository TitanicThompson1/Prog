Todas as funcionalidades foram implementadas.
Utiliza��o de m�ltiplos multimaps com keys e elementos relacionado de forma a obter informa��es pedidas de forma eficiente
Pacotes recomendados sempre dados, tendo em conta N lugares mais visitados por ordem descendente de visitas
Datas t�m em conta, anos bissextos e calend�rio gregoriano.
Mais alguns pormenores corriqueiros foram introduzidos, tendo em conta o funcionamento "real" de uma ag�ncia:
Exemplos:
-N�o recomendar pacotes indispon�veis 
-Datas de incio e fim coerentes
-Inser��o de valores e caracteres incoerentes etc
Cuidado com a Optimiza��o do programa, usando containers e algoritmos expeditos
Possibilidade de voltar atr�s livremente, ou sair em todos os menus.
Programa s� exporta informa��o nova para os ficheiros, se alguma altera��o f�r feita

Melhorias:

- NIF � usado como chave primaria, ou seja, usa-se o NIF para identificar os clientes
- Utilizou se binary search nas fun��es que exigiam procura em vetores, de modo a melhorar o desempenho
- Ao adicionar/eliminar/alterar um cliente/pacote, a ultima etapa � uma de confirmacao em que o utilizador confirmar se quer mesmo efectuar a a��o


