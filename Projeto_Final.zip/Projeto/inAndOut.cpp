

#include "inAndOut.h"

vector<Cliente> importaTodosClientes(string nome_ficheiro)
{
	int i = 0;
	vector<Cliente> clients;
	Cliente temp2;
	string temp;
	string nome, pacotesComprados;
	int nif;
	unsigned agregado, total;
	Address morada;

	ifstream infile(nome_ficheiro);
	while (getline(infile, temp))
	{
		nome = temp;

		getline(infile, temp);
		nif = stoi(temp);

		getline(infile, temp);
		agregado = stoi(temp);

		getline(infile, temp);
		morada.getAddressFromString(temp);

		getline(infile, temp);
		pacotesComprados = temp;

		getline(infile, temp);
		total = stoi(temp);
		
		getline(infile, temp);
		
		temp2.fillCliente(nome, nif, agregado, morada, pacotesComprados, total);
		clients.push_back(temp2);
	}
	
	sort(clients.begin(), clients.end(), sort_clients);

	return clients;
}

void exportaTodosClientes(vector<Cliente> clients, string nome_ficheiro)
{
	ofstream outfile(nome_ficheiro);
	for (int i = 0; i < clients.size(); i++)
	{
		outfile << clients.at(i).getNome() << endl;
		outfile << clients.at(i).getNIF() << endl;
		outfile << clients.at(i).getAgre() << endl;
		outfile << clients.at(i).getMorada().getAddressFormated() << endl;
		outfile << clients.at(i).getPac() << endl;
		outfile << clients.at(i).getTotal() << endl;

		if (i != clients.size() - 1)
			outfile << ":::::::::" << endl;
		
	}
}

void verificarInforma��oPacotes(ifstream &packs_file) {

	int count = 0;
	string aux_string;

	while (!packs_file.eof()) {
		getline(packs_file, aux_string);
		count += 1;
	}
	/*
	testa se ficheiro tem informa��o completa sobre n pacotes tur�sticos
	usamos o facto de que informa��o referente a um pacote utiliza sempre 7 linhas do ficheiro
	 por cada 7 linhas/pacote teremos uma linha com o separador de pacote usado
	por cada n pacotes, teremos n-1 separadores(::::::::::) 7*n linhas e 1 linha com a informa��o sobre �ltimo pacote criado
	*/
	if (((count - 1) - ((count - 1) % 7)) % 7 != 0) {
		cerr << "Ficheiro de pacotes turisticos com informacao incompleta";
		packs_file.close();
		exit(2);
	}

	packs_file.close();


}

vector<Packet> importaPacotes(string nome_ficheiro) {

	//o vector que guardar� os pacotes
	Packet temp;
	vector<Packet> packs;

	//Leitura inicial
	ifstream packs_file;

	string aux_string;
	//abertura de ficheiro dos pacotes tur�sticos
	packs_file.open(nome_ficheiro);

	//verifica se ficheiro abriu
	if (!packs_file.is_open()) {

		cerr << "Impossivel abrir ficheiro dos pacotes turisticos";

		exit(1);
	}

	//controlar n�mero de linhas do ficheiro para evitar erros da leitura de informa��o
	verificarInforma��oPacotes(packs_file);


	//Come�ar a ler ficheiro com os pacotes
	packs_file.open(nome_ficheiro);
	//guarda informa��o sobre o �ltimo pacote criado no ficheiro------ onde usar isto!!?!?!?
	getline(packs_file, aux_string);


	/* int last_pack_created;
	 last_pack_created = stoi(aux_string);
	 */
	unsigned  maxPersons, soldSeats;
	int id;
	double pricePerPerson;
	Date begin;
	Date end;
	vector<string> places;


	while (!packs_file.eof()) {
		//vari�veis para obter a informa��o de cada pacote extra�da do ficheiro

		//obter n�mero do pacote
		getline(packs_file, aux_string);
		id = stoi(aux_string);

		// obter principais locais a visitar
		getline(packs_file, aux_string);
		places = temp.getPlacesFromString(aux_string);								//dont like this

		//Obter data de in�cio
		getline(packs_file, aux_string);

		begin = Date(aux_string);

		//Obter data de fim
		getline(packs_file, aux_string);

		end = Date(aux_string);

		//obter pre�o do pacote por pessoa
		getline(packs_file, aux_string);

		pricePerPerson = stod(aux_string);

		//obter n�mero m�ximo de lugares dispon�vel no pacote
		getline(packs_file, aux_string);

		maxPersons = stoi(aux_string);

		//pacotes vendidos
		getline(packs_file, aux_string);

		soldSeats = stoi(aux_string);

		//Obter e adicionar pacote ao vector de pacotes

		Packet pack;
		pack = Packet(id, places, begin, end, pricePerPerson, maxPersons, soldSeats);
		packs.push_back(pack);

		//Passar ao pr�ximo pacote sinalizado por :::::::::: 
		getline(packs_file, aux_string);


	}
	packs_file.close();

	//ordenamos vector  tendo em conta Id
	sort(packs.begin(), packs.end(), sort_pacotes);
	return packs;

}

void exportaPacotes(vector<Packet> packs, string nome_ficheiro) 
{

	int last_pack = packs.at(packs.size() - 1).getId();
	ofstream export_packets;

	export_packets.open(nome_ficheiro);
	export_packets << last_pack << endl;

	//Escrever no ficheiro os pacotes pretendidos
	for (int i = 0; i < packs.size(); i++) {
		export_packets << packs.at(i) << endl;
		//controlar se temos de escrever no ficheiro o separador de pacotes ou n�o
		if (i < packs.size() - 1) {
			//separador � usado excepto ap�s �ltimo pacote ser guardado no ficheiro, para n pacotes, teremos n -1 separadores
			export_packets << "::::::::::" << endl;
		}

	}
	export_packets.close();
}
