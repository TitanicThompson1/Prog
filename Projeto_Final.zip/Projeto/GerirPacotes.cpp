
#include<iostream>
#include<string>
#include<sstream>
#include<fstream>

#include"Packet.h"
#include"GerirPacotes.h"
#include"Date.h"
#include"procura.h"
#include "get_out.h"

using namespace std;

int criarPacote(Packet &pack ,int las_pack_created) {

	cout << "(Introduza 0 para voltar para o menu anterior)" << endl << endl;

	//Objectos necess�rios das Classes Packet e Date respectivamente
	Date date_begin;
	Date date_end;

	//Para controlar introdu��o de informa��o do pacote
	bool valid = false;

	//Vari�veis necess�rias para os atributos do objecto pack da Classe Packet que queremos criar
	unsigned maxPersons, soldSeats;
	int id;
	double pricePerPerson;
	string place;
	vector<string> places;

	//para controlar inser��o de mais s�tios a visitar
	string decisao;

	Packet temp;

	string dec_str;

	//Locais do pacote a ser criado
	cin.ignore();
	//Introduzir o principal destino tur�stico
	cout << "Introduza o principal local turistico de destino:  ";

	getline(cin, place);

	//verficia se pretende cancelar
	if (place == "0")
	{
		return 1;
	}
	places.push_back(place);


	// controlo da decis�o de inserir mais destinos ou n�o
	cout << endl << "Existem mais destinos a visitar? (S/N)  ";
	cin >> decisao;

	while (decisao != "S" && decisao != "N") {

		//verficia se pretende cancelar
		if (decisao == "0")
		{
			return 1;
		}
		cin.clear();
		cin.ignore(1000, '\n');
		cerr << "Comando errado. Por favor introduza N (N�o) ou S (Sim):  ";
		cin >> decisao;
	}

	//Introduzir mais locais
	while (decisao == "S")
	{

		cout << "Introduza outro local turistico de destino:  ";
		cin.ignore();															//necessario pois anteriormente se usou um cin (o cin deixa um espaco no input buffer)
		getline(cin, place);

		if (place == "0")
		{
			return 1;
		}

		places.push_back(place);

		cout << "Deseja continuar? (S/N)  ";
		cin >> decisao;

		//Controlar comandos inseridos pelo utilizador para continuar
		while (decisao != "S" && decisao != "N") {

			//verficia se pretende cancelar
			if (decisao == "0")
			{
				return 1;
			}
			cin.clear();
			cin.ignore(1000, '\n');
			cerr << "Comando errado. Por favor introduza N (N�o) ou S (Sim):  ";
			cin >> decisao;
		}
	}
	//::::::Datas do pacote::::::::::

	//Data de in�cio   
	cout << "Insira a data de inicio:" << endl;
	date_begin.insertDate();
	
	//verficia se pretende cancelar
	if (date_begin.getYear() == 0)
	{
		return 1;
	}


	//Data de fim

	// controlar inser��o da data de fim   
	bool valid_date = false;

	//Verificar validade da data de fim tendo em conta que tem de ser >= a data de in�cio
	while (!valid_date) {
		//data de fim que queremos no pacote
		cout << "Insira a data do fim:" << endl;
		date_end.insertDate();

		//verficia se pretende cancelar
		if (date_begin.getYear() == 0)
		{
			return 1;
		}

		//verificar se data de fim pretendida � maior ou igual que a data de in�cio!!(basta verificar date_begin <= date_end)
		valid_date = date_begin <= date_end;
		if (valid_date == false)
		{
			cerr << "Data invalida! Introduza novamente" << endl;
		}

	}


	//Pre�o do pacote por pessoa


	cout << "Introduza o pre�o por pessoa:  ";
	cin >> pricePerPerson;

	//preven��o de erro
	while (cin.fail() || pricePerPerson <= 0) {// pre�os negativos n�o fazem sentido!

		//verficia se pretende cancelar
		if (pricePerPerson == 0 && !cin.fail())
		{
			return 1;
		}
		cin.clear();
		cin.ignore(1000, '\n');
		cerr << "Valor inserido inv�lido!Intoduza um pre�o valido:  ";
		cin >> pricePerPerson;

	}


	//M�ximo de pacotes para venda

	//valor que ser� usado para alterar maxPersons no pacote

	//vari�vel para controlar altera��o
	bool valid_max_persons = false;

	cout << "Introduza o numero de lugares disponiveis:  ";

	cin >> maxPersons;
	while (!valid_max_persons) {

		// erro de valores inv�lidos
		if (cin.fail() || maxPersons == 4294967295) 
		{
			cin.clear();
			cin.ignore(1000, '\n');
			cerr << "Erro. Intoduza um valor valido:  ";
			cin >> maxPersons;

		}

		//verficia se pretende cancelar
		else if (maxPersons == 0 && !cin.fail())
		{
			return 1;
		}
		//Outras nuances a verificar na altera��o de maxPersons
		else {

			valid_max_persons = true;

		}

	}

	//soldSeats ser� sempre 0 por defeito
	soldSeats = 0;
	if (maxPersons == soldSeats) {
		//Id ser� negativo e com Id menor ou maior do que o �ltimo pacote criado, consoante o �ltimo seja negativo ou positivo 
		id = -abs(las_pack_created);
	}

	else {
		//Id positivo
		id = abs(las_pack_created) + 1;

	}

	

	//Pacote fica definido!
	temp = Packet(id, places, date_begin, date_end, pricePerPerson, maxPersons, soldSeats);
	system("cls");
	dec_str = confirmarPacote(temp, "Deseja adicionar este pacote? Introduza S(Sim) ou N(Nao)");

	if (dec_str == "S")
	{
		pack= Packet(id, places, date_begin, date_end, pricePerPerson, maxPersons, soldSeats);

	}
	else
	{
		return 1;
	}

	return 0;

}

int eliminaPacote(vector<Packet> &packs) {

	//vari�veis para verificar validade do id, obter index do pacote pretendido e id

	bool valid_entry = false;
	int index;
	int id;
	string dec_str;


	while (!valid_entry) {
		cout << "Insira Id do pacote a apagar: ";
		cin >> id;
		cout << endl;
		if (!cin || id == 0) {

			if (id == 0 && !cin.fail())
			{
				return 1;
			}
			cin.clear();
			cin.ignore(1000, '\n');
			cerr << "Id inserido invalido, tente novamente!" << endl;

		}
		//Verificar se Id inserido existe, se sim pacote pacote pretendido ser� apagado
		else {

			//verificar se pacote que pretendemos apagar de facto existe
			//Usa-se valor absoluto por causa de poss�veis Id negativos!
			index = procuraPosPacote(packs, 0, id);
			if (index == -1) {
				cerr << "Pacote que pretende apagar nao existe, tente novamente!" << endl;
			}

			else {
				//Id que se pretende eliminar � v�lido!!
				valid_entry = true;
			}

		}

	}

	system("cls");
	dec_str = confirmarPacote(packs.at(index), "Deseja eliminar este pacote? Introduza S(Sim) ou N(Nao)");

	if (dec_str == "S")
	{
		//Removemos o pacote pretendido!!!
		packs.erase(packs.begin() + index);

	}
	else
	{
		return 1;
	}

	return 0;
}

int alterarPacote(vector<Packet> &packs) {

	
	string dec_str;
	int id;
	unsigned short campo_a_alterar;

	cout << "Introduza o numero identificador do pacote:  ";
	cin >> id;
	

	//controlamos ID introduzido, usando sempre valores absolutos para os casos de Id negativos n�o criarem conflitos
	while (abs(id) > abs(packs.back().getId()) || !cin || abs(id) < 1 || procuraPosPacote(packs,0,id) == -1) {									//verifica se id � valido e se existe

		//verifica se o utilizador deseja cnacelar
		if (id == 0 && !cin.fail())
		{
			return 1;
		}
		cin.clear();
		cin.ignore(1000, '\n');
		cerr << "Pacote nao existe. Introduza um numero identificador do pacote valido: ";
		cin >> id;

	}

	int pos_pacote = procuraPosPacote(packs, 0, id);

	system("cls");
	cout << "Campo a alterar:  "
		<< endl << "1 - Locais turisticos de destino "
		<< endl << "2 - Data de inicio da viagem "
		<< endl << "3 - Data de fim da viagem "
		<< endl << "4 - Pre�o por pessoa "
		<< endl << "5 - N�mero de pacotes disponiveis;" << endl;
	//N�o faz sentido poder alterar soldSeats de um pacote, isso s� deve ser feito ao haver uma compra


	cin >> campo_a_alterar;
	//verifica se o campo_a_alterar � valido
	while (campo_a_alterar < 1 || campo_a_alterar > 5 || !cin) {

		//verifica se o utilizador deseja cnacelar
		if (campo_a_alterar== 0 && !cin.fail())
		{
			return 1;
		}

		cin.clear();
		cin.ignore(1000, '\n');
		cerr << "Campo invalido. Por favor escolha um campo entre 1 e 5!";
		cin >> campo_a_alterar;


	}

	//vari�veis a utilizar para os v�rios casos poss�veis de altera��o
	string temp, decisao;
	vector<string> local;
	Date date_begin;
	Date date_end;
	bool valid_date = false;


	switch (campo_a_alterar)

	{
	case 1:
		//Introduzir o principal destino tur�stico
		cout << "Introduza o principal local turistico de destino:  ";
		cin.ignore();
		getline(cin, temp);
		if (temp == "0")
		{
			return 1;
		}

		local.push_back(temp);

		cout << "Existem mais destinos a visitar? (S/N)  ";
		cin >> decisao;
		//controlo da decis�o de inserir mais destinos ou n�o
		while (decisao != "S" && decisao != "N") {

			//verifica se o utilizador deseja cancelar
			if (decisao == "0" )
			{
				return 1;
			}

			cin.clear();
			cin.ignore(1000, '\n');
			cerr << "Comando errado. Por favor introduza N (Nao) ou S (Sim):  ";
			cin >> decisao;
		}

		//Introduzir mais locais
		while (decisao == "S") {

			cout << "Introduza outro local turistico de destino:  ";
			cin.ignore();
			getline(cin, temp);

			//verifica se o utilizador deseja cancelar
			if (temp == "0")
			{
				return 1;
			}

			local.push_back(temp);
			cout << "Deseja continuar? (S/N)  ";
			cin >> decisao;

			//Controlar comandos inseridos pelo utilizador para continuar
			while (decisao != "S" && decisao != "N") {

				//verifica se o utilizador deseja cancelar
				if (decisao == "0")
				{
					return 1;
				}
				cerr << "Comando errado. Por favor introduza N (Nao) ou S (Sim):  ";
				cin >> decisao;
			}

		}
		system("cls");
		dec_str = confirmarPacote(packs.at(pos_pacote), "Deseja alterar este pacote? Introduza S(Sim) ou N(Nao)");

		if (dec_str == "S")
		{
			
			packs.at(pos_pacote).setPlaces(local);

		}
		else
		{
			return 1;
		}

		return 0;
		
		break;
	case 2:


		valid_date = false;// controlar altera��o da data de in�cio!

		//Verificar validade da data de in�cio tendo em conta que tem de ser <= a data do fim
		while (!valid_date) {
			//data de in�cio que queremos inserir no pacote de forma a alterar o mesmo
			date_begin.insertDate();

			//verifica se o utilizador deseja cancelar
			if (date_begin.getYear() == 0)
			{
				return 1;
			}
			//verificar se data de in�cio pretendida � menor ou igual data de fim!!
			valid_date = date_begin <= packs.at(abs(id) - 1).getEndDate();


		}

		system("cls");
		dec_str = confirmarPacote(packs.at(pos_pacote), "Deseja alterar este pacote? Introduza S(Sim) ou N(Nao)");
		if (dec_str == "S")
		{

			//altera��o efectuada
			packs.at(pos_pacote).setBeginDate(date_begin);

		}
		else
		{
			return 1;
		}

		return 0;
		break;

	case 3:


		valid_date = false;// controlar altera��o da data de in�cio!

		//Verificar validade da data de fim tendo em conta que tem de ser >= a data do fim
		while (!valid_date) {
			//data de in�cio que queremos inserir no pacote de forma a alterar o mesmo
			date_end.insertDate();

			//verifica se o utilizador deseja cancelar
			if (date_end.getYear() == 0)
			{
				return 1;
			}
			//verificar se data de fim pretendida � maior ou igual que a data de in�cio!!(basta verificar date_begin <= date_end)
			valid_date = packs.at(abs(id) - 1).getBeginDate() <= date_end;

		}

		system("cls");
		dec_str = confirmarPacote(packs.at(pos_pacote), "Deseja alterar este pacote? Introduza S(Sim) ou N(Nao)");
		if (dec_str == "S")
		{

			//altera��o � efectuada
			packs.at(pos_pacote).setEndDate(date_end);

		}
		else
		{
			return 1;
		}

		return 0;

		
		break;
	case 4:
		double valor;
		cout << "Introduza o pre�o por pessoa:  ";
		cin >> valor;

		//preven��o de erro
		while (cin.fail() || valor <= 0) {// n�o faz sentido poder introduzir valores negativos de um pre�o!!!		

			//verifica se o utilizador deseja cancelar
			if (!cin.fail() && valor == 0)
			{
				return 1;
			}
			cin.clear();
			cin.ignore(1000, '\n');
			cerr << "Erro. Intoduza um pre�o valido:  ";
			cin >> valor;

		}

		system("cls");
		dec_str = confirmarPacote(packs.at(pos_pacote), "Deseja alterar este pacote? Introduza S(Sim) ou N(Nao)");
		if (dec_str == "S")
		{

			//altera��o � efectuada
			packs.at(pos_pacote).setPricePerPerson(valor);

		}
		else
		{
			return 1;
		}

		return 0;


		break;
	case 5:
		//valor que ser� usado para alterar maxPersons no pacote
		unsigned valor_int;
		//vari�vel para controlar altera��o
		bool valid_max_persons = false;

		cout << "Introduza o numero de lugares disponiveis:  ";

		cin >> valor_int;
		while (!valid_max_persons) {
			

			//verifica se o utilizador deseja cancelar
			if (!cin.fail() && valor_int == 0)
			{
				return 1;
			}
			// erro de valores inv�lidos
			if (cin.fail() || valor_int == 4294967295) {
				cin.clear();
				cin.ignore(1000, '\n');
				cerr << "Erro. Intoduza um valor valido:  ";
				cin >> valor_int;

			}

			//Outras nuances a verificar na altera��o de maxPersons
			else {

				//Verificar se maxPersons >= a soldSeats
				pos_pacote = procuraPosPacote(packs, 0, id);
				if (valor_int < packs.at(pos_pacote).getSoldSeats()) {
					
					cerr << "Numero de lugares disponiveis tem de ser maior ou igual ao numero de lugares vendidos! Introduza um valor valido: ";
					cin >> valor_int;
					
					//verifica se o utilizador deseja cancelar
					if (!cin.fail() && valor == 0)
					{
						return 1;
					}
				}
				pos_pacote = procuraPosPacote(packs, 0, id);


				//tratar do caso em que maxPersons ==soldSeats
				if (valor_int == packs.at(pos_pacote).getSoldSeats()) {
					//desta forma, cobre os casos em que pacote j� tinha maxPersons == soldSeats e se faz uma altera��o redundante!
					packs.at(pos_pacote).setId(-abs(id));// � intriduzido um id negativo
					valid_max_persons = true;

				}

				//altera��o pretendida � v�lida
				valid_max_persons = true;



			}

		}

		system("cls");
		dec_str = confirmarPacote(packs.at(pos_pacote), "Deseja alterar este pacote? Introduza S(Sim) ou N(Nao)");
		if (dec_str == "S")
		{

			//efectuar altera��o
			packs.at(pos_pacote).setMaxPersons(valor_int);

		}
		else
		{
			return 1;
		}

		return 0;
		

		break;
	}
	return 0;

}