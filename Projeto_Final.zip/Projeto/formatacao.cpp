#include "formatacao.h"



void le_clientes_formatado(vector<Cliente> clients) {

	string temp;																//linha que ese est� a ler
	int i = 0;																	//indice da linha

	cout << setw(20) << left << "Nome";
	cout << "|";
	cout << setw(10) << left << "NIF";
	cout << "|";
	cout << setw(10) << left << "Agregado";
	cout << "|";
	cout << setw(60) << left << "Morada";
	cout << "|";
	cout << setw(20) << left << "Pacotes comprados";
	cout << "|";
	cout << setw(6) << left << "Total" << endl;

	cout << "----------------------------------------------------------------------------------------------------------------------------" << endl;

	
	for (int i = 0; i < clients.size(); i++) {
		
		cout << setw(20) << left << clients.at(i).getNome();
		cout << "|";
		
		cout << setw(10) << left << clients.at(i).getNIF();
		cout << "|";
		
		cout << setw(10) << left << clients.at(i).getAgre();
		cout << "|";

		cout << setw(60) << left << clients.at(i).getMorada().getAddressFormated();
		cout << "|";

		cout << setw(20) << left << clients.at(i).getPac();
		cout << "|";

		cout << setw(6) << left << clients.at(i).getTotal() << endl;
		

	
	
	}
	
}

void le_pacotes_formatado(vector<Packet> packs)
{
	
	cout << setw(4) << left << "ID";
	cout << "|";
	cout << setw(67) << left << "Principais destinos turisticos";
	cout << "|";
	cout << setw(12) << left << "Data inicio";
	cout << "|";
	cout << setw(12) << left << "Data fim";
	cout << "|";
	cout << setw(15) << left << "Preco p/pessoa";
	cout << "|";
	cout << setw(35) << left << "Lugares inicialmente disponiveis";
	cout << "|";
	cout << setw(18) << left << "Lugares vendidos" << endl;

	cout << "---------------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl;

	
	for (int i = 0; i < packs.size(); i++) {

		cout << setw(4) << left << packs.at(i).getId();
		cout << "|";

		cout << setw(67) << left << packs.at(i).getPlacesFormated();
		cout << "|";

		
		cout << setw(12) << left << packs.at(i).getBeginDate() << "  ";
		cout << "|";
		
		cout << setw(12) << left << packs.at(i).getEndDate() << "  ";
		cout << "|";

		cout << setw(15) << left << packs.at(i).getPricePerPerson();
		cout << "|";

		cout << setw(35) << left << packs.at(i).getMaxPersons();
		cout << "|";

		cout << setw(18) << left << packs.at(i).getSoldSeats() << endl;

	}
	

}

void le_pacote_formatado(vector<Packet> packs, int pos_pacote)
{
	cout << "Id:  " << packs.at(pos_pacote).getId() << endl <<
		"Principais lugares disponiveis:  " << packs.at(pos_pacote).getPlacesFormated() << endl <<
		"Data de inicio:  " << packs.at(pos_pacote).getBeginDate()<< endl <<
		"Data de fim:  " << packs.at(pos_pacote).getEndDate() << endl <<
		"Preco por pessoa:  " << packs.at(pos_pacote).getPricePerPerson() << endl <<
		"Lugares originalmente disponiveis:  " << packs.at(pos_pacote).getMaxPersons() << endl <<
		"Lugares vendidos:  " << packs.at(pos_pacote).getSoldSeats() << endl;

}
