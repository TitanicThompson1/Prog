#pragma once

#include <iostream>

#include "Packet.h"

Packet criarPacote();

void eliminaPacote(vector<Packet> packs);

void alteraPacote(vector<Packet> packs);