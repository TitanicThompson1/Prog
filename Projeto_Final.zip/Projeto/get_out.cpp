#include <iostream>
#include <string>

#include "get_out.h"


/*
@Mostra na consola as op��es que se pode realizar
n�o tem parametros de entrada
RETURN: 0 se o utilizador quiser voltar para o menu anterior, -1 se quiser sair do programa
*/
int opcao_a_realizar() {
	
	int dec;

	cout << endl << "[0] Voltar" << endl
			<< "[-1] Sair" << endl;
	cin >> dec;

	while ((dec != -1 && dec != 0) || cin.fail()) {

		cin.clear();
		cin.ignore(100, '\n');
		cerr << "Erro. Numero invalido. Por favor introduza um numero valido:  "; cin >> dec;
	}
	return dec;
}

string confirmarCliente(Cliente objecto, string mensagem)
{
	string dec;

	cout << objecto;
	cout << endl << endl;
	cout << mensagem << endl;

	cin >> dec;

	//verifica se a decisao � S ou N
	while (dec != "S" && dec != "N")
	{

		//verifica se o utilizador quer cancelar
		if (dec == "0")
		{
			return "N";
		}
		cin.clear();
		cin.ignore(100, '\n');

		cerr << "Instrucao errada. Por favor introduza  S(Sim) ou N(Nao)"; cin >> dec;
	}
	return dec;
}

string confirmarPacote(Packet objecto, string mensagem)
{
	string dec;

	cout << "Id:  " << objecto.getId() << endl <<
		"Principais lugares disponiveis:  " << objecto.getPlacesFormated() << endl <<
		"Data de inicio:  " << objecto.getBeginDate() << endl <<
		"Data de fim:  " << objecto.getEndDate() << endl <<
		"Preco por pessoa:  " << objecto.getPricePerPerson() << endl <<
		"Lugares originalmente disponiveis:  " << objecto.getMaxPersons() << endl <<
		"Lugares vendidos:  " << objecto.getSoldSeats() << endl;
	cout << endl << endl;
	cout << mensagem << endl;

	cin >> dec;

	//verifica se a decisao � S ou N
	while (dec != "S" && dec != "N")
	{

		//verifica se o utilizador quer cancelar
		if (dec == "0")
		{
			return "N";
		}
		cin.clear();
		cin.ignore(100, '\n');

		cerr << "Intrucao errada. Por favor introduza  S(Sim) ou N(Nao)"; cin >> dec;
	}
	return dec;
}